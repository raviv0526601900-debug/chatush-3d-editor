// ייבוא DWG/DXF בדפדפן בעזרת LibreDWG (WebAssembly). נטען רק כשצריך (~11MB).
// LibreDWG — GPL-3.0 © Free Software Foundation. עטיפת JS: @mlightcad/libredwg-web (GPL-3.0).
let libPromise = null;
async function lib() {
  if (!libPromise) libPromise = (async () => {
    const mod = await import('../vendor/libredwg/dist/libredwg-web.js');
    const base = new URL('../vendor/libredwg/wasm', import.meta.url).href;
    const inst = await mod.LibreDwg.create(base);
    return { inst, mod };
  })();
  return libPromise;
}

const UNIT_TO_CM = { 1: 2.54, 2: 30.48, 4: 0.1, 5: 1, 6: 100, 14: 10 };

function bulgeArc(p1, p2, bulge, out, layer, tf) {
  // קירוב קשת של פוליליין (bulge) לקטעים קצרים
  const th = 4 * Math.atan(bulge);
  const dx = p2[0] - p1[0], dy = p2[1] - p1[1];
  const c = Math.hypot(dx, dy);
  if (!c || Math.abs(th) < 1e-3) { out.push([layer, ...tf(p1), ...tf(p2)]); return; }
  const r = c / (2 * Math.sin(th / 2));
  const mx = (p1[0] + p2[0]) / 2, my = (p1[1] + p2[1]) / 2;
  const h = r * Math.cos(th / 2);
  const cx = mx - (dy / c) * h, cy = my + (dx / c) * h;
  const a0 = Math.atan2(p1[1] - cy, p1[0] - cx);
  const n = Math.max(4, Math.min(24, Math.ceil(Math.abs(th) / 0.2)));
  let prev = p1;
  for (let i = 1; i <= n; i++) {
    const a = a0 + (th * i) / n;
    const q = [cx + Math.abs(r) * Math.cos(a) * Math.sign(r || 1), cy + Math.abs(r) * Math.sin(a) * Math.sign(r || 1)];
    const qq = i === n ? p2 : q;
    out.push([layer, ...tf(prev), ...tf(qq)]); prev = qq;
  }
}

function collect(db) {
  const segs = [];
  const blocks = new Map();
  for (const b of db.tables?.BLOCK_RECORD?.entries || []) blocks.set(b.name, b);
  const MAX = 80000;
  const walk = (ents, tf, depth, layerOverride) => {
    for (const e of ents || []) {
      if (segs.length > MAX) return;
      if (e.isInPaperSpace) continue;
      const layer = (layerOverride && (e.layer === '0' || !e.layer)) ? layerOverride : (e.layer || '0');
      switch (e.type) {
        case 'LINE': segs.push([layer, ...tf([e.startPoint.x, e.startPoint.y]), ...tf([e.endPoint.x, e.endPoint.y])]); break;
        case 'LWPOLYLINE': case 'POLYLINE2D': case 'POLYLINE3D': {
          const v = e.vertices || []; if (v.length < 2) break;
          const closed = (e.flag & 1) === 1 || (e.flag & 512) === 512;
          const n = closed ? v.length : v.length - 1;
          for (let i = 0; i < n; i++) {
            const a = v[i], b = v[(i + 1) % v.length];
            if (a.bulge) bulgeArc([a.x, a.y], [b.x, b.y], a.bulge, segs, layer, tf);
            else segs.push([layer, ...tf([a.x, a.y]), ...tf([b.x, b.y])]);
          }
          break;
        }
        case 'ARC': case 'CIRCLE': {
          const s = e.type === 'ARC' ? e.startAngle : 0;
          let en = e.type === 'ARC' ? e.endAngle : Math.PI * 2;
          if (en < s) en += Math.PI * 2;
          const n = Math.max(8, Math.min(48, Math.ceil((en - s) / 0.15)));
          let prev = null;
          for (let i = 0; i <= n; i++) {
            const a = s + ((en - s) * i) / n;
            const p = [e.center.x + e.radius * Math.cos(a), e.center.y + e.radius * Math.sin(a)];
            if (prev) segs.push([layer, ...tf(prev), ...tf(p)]);
            prev = p;
          }
          break;
        }
        case 'INSERT': {
          if (depth > 3) break;
          const b = blocks.get(e.name); if (!b) break;
          const ip = e.insertionPoint || { x: 0, y: 0 }, bp = b.basePoint || { x: 0, y: 0 };
          const sx = e.xScale || 1, sy = e.yScale || 1, r = e.rotation || 0;
          const cs = Math.cos(r), sn = Math.sin(r);
          const sub = ([x, y]) => { const lx = (x - bp.x) * sx, ly = (y - bp.y) * sy; return tf([ip.x + lx * cs - ly * sn, ip.y + lx * sn + ly * cs]); };
          walk(b.entities, sub, depth + 1, layer);
          break;
        }
        default: break;
      }
    }
  };
  walk(db.entities, (p) => p, 0, null);
  return segs;
}

// DXF נקרא עם dxf-parser (MIT) ומומר לאותו מבנה של LibreDWG
let dxfPromise = null;
function loadDxfParser() {
  if (!dxfPromise) dxfPromise = new Promise((res, rej) => {
    if (window.DxfParser) return res(window.DxfParser);
    const s = document.createElement('script');
    s.src = new URL('../vendor/dxf-parser/dxf-parser.js', import.meta.url).href;
    s.onload = () => res(window.DxfParser); s.onerror = rej;
    document.head.appendChild(s);
  });
  return dxfPromise;
}
function dxfToDb(d) {
  const P = (v) => ({ x: v?.x || 0, y: v?.y || 0 });
  const conv = (e) => {
    const base = { type: e.type, layer: e.layer, isInPaperSpace: !!e.inPaperSpace };
    switch (e.type) {
      case 'LINE': return { ...base, startPoint: P(e.vertices?.[0]), endPoint: P(e.vertices?.[1]) };
      case 'LWPOLYLINE': case 'POLYLINE': return { ...base, type: 'LWPOLYLINE', flag: e.shape || e.closed ? 1 : 0, vertices: (e.vertices || []).map((v) => ({ x: v.x, y: v.y, bulge: v.bulge || 0 })) };
      case 'ARC': return { ...base, center: P(e.center), radius: e.radius, startAngle: e.startAngle, endAngle: e.endAngle };
      case 'CIRCLE': return { ...base, center: P(e.center), radius: e.radius };
      case 'INSERT': return { ...base, name: e.name, insertionPoint: P(e.position), xScale: e.xScale || 1, yScale: e.yScale || 1, rotation: ((e.rotation || 0) * Math.PI) / 180 };
      default: return base;
    }
  };
  const blocks = Object.values(d.blocks || {}).map((b) => ({ name: b.name, basePoint: P(b.position), entities: (b.entities || []).map(conv) }));
  return { header: { INSUNITS: d.header?.$INSUNITS, ACADVER: d.header?.$ACADVER }, tables: { BLOCK_RECORD: { entries: blocks } }, entities: (d.entities || []).map(conv) };
}

// קורא קובץ ומחזיר קטעים בס"מ (y כלפי מטה, מיושר לראשית) + שכבות
export async function readCad(file, onStatus = () => {}) {
  const isDxf = /\.dxf$/i.test(file.name);
  const buf = await file.arrayBuffer();
  let db;
  if (isDxf) {
    onStatus('קורא את קובץ ה-DXF…');
    const Parser = await loadDxfParser();
    const d = new Parser().parseSync(new TextDecoder().decode(buf));
    if (!d) throw new Error('לא הצלחתי לקרוא את קובץ ה-DXF.');
    db = dxfToDb(d);
  } else {
    onStatus('טוען את מנוע LibreDWG…');
    const { inst, mod } = await lib();
    onStatus('קורא את קובץ ה-DWG…');
    const data = inst.dwg_read_data(buf, mod.Dwg_File_Type.DWG);
    if (data == null) throw new Error('לא הצלחתי לקרוא את הקובץ. ייתכן שהגרסה חדשה מדי (נתמך עד AutoCAD 2018) — נסו לשמור כ-DXF.');
    db = inst.convert(data);
    try { inst.dwg_free(data); } catch (_) {}
  }
  let raw = collect(db);
  if (!raw.length) throw new Error('לא נמצאו קווים בקובץ (ייתכן שהשרטוט נמצא ב-Layout ולא ב-Model).');
  // סינון קווים רחוקים (קווי עזר, נקודות זבל) לפי אחוזונים — כדי שהתוכנית תתמקד בשרטוט עצמו
  if (raw.length > 50) {
    const xs = [], ys = [];
    for (const [, x1, y1, x2, y2] of raw) { xs.push(x1, x2); ys.push(y1, y2); }
    xs.sort((a, b) => a - b); ys.sort((a, b) => a - b);
    const q = (arr, f) => arr[Math.floor((arr.length - 1) * f)];
    const x0 = q(xs, 0.02), x9 = q(xs, 0.98), y0 = q(ys, 0.02), y9 = q(ys, 0.98);
    const mx = (x9 - x0) * 0.25 + 1, my = (y9 - y0) * 0.25 + 1;
    const inb = (x, y) => x >= x0 - mx && x <= x9 + mx && y >= y0 - my && y <= y9 + my;
    const f = raw.filter(([, x1, y1, x2, y2]) => inb(x1, y1) && inb(x2, y2));
    if (f.length > raw.length * 0.5) raw = f;
  }
  // יחידות
  let unit = UNIT_TO_CM[db.header?.INSUNITS];
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const [, x1, y1, x2, y2] of raw) { minX = Math.min(minX, x1, x2); maxX = Math.max(maxX, x1, x2); minY = Math.min(minY, y1, y2); maxY = Math.max(maxY, y1, y2); }
  const span = Math.max(maxX - minX, maxY - minY);
  const guessed = !unit;
  if (!unit) unit = span > 8000 ? 0.1 : span > 80 ? 1 : 100; // מ"מ / ס"מ / מטרים
  const layers = new Map();
  for (const s of raw) layers.set(s[0], (layers.get(s[0]) || 0) + 1);
  return { raw, unit, guessed, bounds: { minX, minY, maxX, maxY }, layers, version: db.header?.ACADVER || '' };
}

// המרה לתוכנית: קנה מידה, היפוך ציר Y והזזה לראשית
export function toPlan(res, unit) {
  const { minX, maxY } = res.bounds;
  return res.raw.map(([layer, x1, y1, x2, y2]) => [layer,
    Math.round((x1 - minX) * unit * 10) / 10, Math.round((maxY - y1) * unit * 10) / 10,
    Math.round((x2 - minX) * unit * 10) / 10, Math.round((maxY - y2) * unit * 10) / 10]);
}

export const WALL_LAYER_RE = /wall|קיר|קירות|a-wall|mur|muro|wand|bearing|בניה|בנייה|בלוק|block/i;

// זיהוי קירות: זוגות קווים מקבילים במרחק 5–45 ס"מ → קיר עם עובי; קווים בודדים ארוכים → קיר בעובי ברירת מחדל
export function detectWalls(segs, { single = true, defaultT = 12 } = {}) {
  const L = segs.map(([, x1, y1, x2, y2]) => {
    const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy);
    return { x1, y1, x2, y2, len, ux: dx / (len || 1), uy: dy / (len || 1), used: false };
  }).filter((s) => s.len >= 30).sort((a, b) => b.len - a.len).slice(0, 4000);
  const walls = [];
  for (let i = 0; i < L.length; i++) {
    const a = L[i]; if (a.used) continue;
    let best = null;
    for (let j = i + 1; j < L.length; j++) {
      const b = L[j]; if (b.used) continue;
      const dot = Math.abs(a.ux * b.ux + a.uy * b.uy); if (dot < 0.9994) continue;
      // מרחק אנכי בין הקווים
      const nx = -a.uy, ny = a.ux;
      const dd = Math.abs((b.x1 - a.x1) * nx + (b.y1 - a.y1) * ny);
      if (dd < 5 || dd > 45) continue;
      // חפיפה לאורך הקו
      const t1 = (b.x1 - a.x1) * a.ux + (b.y1 - a.y1) * a.uy, t2 = (b.x2 - a.x1) * a.ux + (b.y2 - a.y1) * a.uy;
      const s0 = Math.max(0, Math.min(t1, t2)), s1 = Math.min(a.len, Math.max(t1, t2));
      const ov = s1 - s0;
      if (ov < Math.min(a.len, b.len) * 0.5) continue;
      if (!best || dd < best.dd) best = { b, dd, s0, s1, nx, ny, sgn: Math.sign((b.x1 - a.x1) * nx + (b.y1 - a.y1) * ny) };
    }
    if (best) {
      a.used = best.b.used = true;
      const off = (best.dd / 2) * best.sgn;
      walls.push({ a: [Math.round(a.x1 + a.ux * best.s0 + best.nx * off), Math.round(a.y1 + a.uy * best.s0 + best.ny * off)],
                   b: [Math.round(a.x1 + a.ux * best.s1 + best.nx * off), Math.round(a.y1 + a.uy * best.s1 + best.ny * off)],
                   t: Math.round(best.dd) });
    }
  }
  if (single) for (const s of L) if (!s.used && s.len >= 60) walls.push({ a: [Math.round(s.x1), Math.round(s.y1)], b: [Math.round(s.x2), Math.round(s.y2)], t: defaultT });
  return joinCorners(walls);
}

// סגירת פינות: קצה קיר שקרוב לקו של קיר אחר מוארך עד נקודת החיתוך
function joinCorners(walls, tol = 40) {
  const inter = (p1, p2, p3, p4) => {
    const d = (p1[0] - p2[0]) * (p3[1] - p4[1]) - (p1[1] - p2[1]) * (p3[0] - p4[0]);
    if (Math.abs(d) < 1e-6) return null;
    const t = ((p1[0] - p3[0]) * (p3[1] - p4[1]) - (p1[1] - p3[1]) * (p3[0] - p4[0])) / d;
    return [p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1])];
  };
  for (const w of walls) for (const k of ['a', 'b']) {
    let best = null;
    for (const o of walls) {
      if (o === w) continue;
      const q = inter(w.a, w.b, o.a, o.b); if (!q) continue;
      const d = Math.hypot(q[0] - w[k][0], q[1] - w[k][1]);
      // החיתוך צריך להיות בתוך הקיר השני (או קרוב לקצה שלו)
      const ol = Math.hypot(o.b[0] - o.a[0], o.b[1] - o.a[1]);
      const dq = Math.hypot(q[0] - o.a[0], q[1] - o.a[1]) + Math.hypot(q[0] - o.b[0], q[1] - o.b[1]) - ol;
      if (d < tol && dq < tol && (!best || d < best.d)) best = { q, d };
    }
    if (best) w[k] = [Math.round(best.q[0]), Math.round(best.q[1])];
  }
  return walls.filter((w) => Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]) >= 20);
}
