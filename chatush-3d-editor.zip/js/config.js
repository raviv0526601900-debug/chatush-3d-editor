// הגדרות חיבור ציבוריות (מפתח anon ציבורי — ההרשאות נאכפות בשרת לפי RLS)
export const SUPABASE_URL = 'https://kcaqbdvuwdmchapgznak.supabase.co';
export const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtjYXFiZHZ1d2RtY2hhcGd6bmFrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI1Mjg0NjMsImV4cCI6MjEwODEwNDQ2M30.XlsgZf-5GfqWdq5B1XInamn4_5OIo7d802-P4B31Xss';
export const APP_URL = 'https://studio-a-i-janb6z.flutterflow.app';
