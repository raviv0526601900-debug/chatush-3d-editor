// בניית המודל התלת־ממדי מתוך קובץ הסצנה (JSON). יחידות: ס"מ. תוכנית (x,y) → תלת־ממד (x, גובה, y)
import * as THREE from 'three';
import { getMaterial, texScale } from './materials.js';
import { buildItem, CATALOG } from './catalog.js';

// UV בקנה מידה אמיתי לקופסה — כדי שלבנים/אריחים לא יימתחו
function worldUV(geom, w, h, d, scale) {
  const uv = geom.attributes.uv;
  const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) {
    const [su, sv] = dims[f];
    for (let i = 0; i < 4; i++) {
      const k = f * 4 + i;
      uv.setXY(k, uv.getX(k) * su / scale, uv.getY(k) * sv / scale);
    }
  }
  uv.needsUpdate = true;
}

function wallBox(len, h, t, mat, x0, y0) {
  const g = new THREE.BoxGeometry(len, h, t);
  if (mat.map) worldUV(g, len, h, t, texScale(mat.userData.key));
  const m = new THREE.Mesh(g, mat);
  m.position.set(x0 + len / 2, y0 + h / 2, 0);
  m.castShadow = true; m.receiveShadow = true;
  return m;
}

export function wallLength(w) { return Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]); }

function wallMaterial(scene, w) {
  if (w.kind === 'demolish') return getMaterial('mark_demolish');
  if (w.kind === 'new' && scene.settings?.marks) return getMaterial('mark_new');
  return getMaterial(w.mat || 'paint_white');
}

const at = (m, x, y, z) => { m.position.set(x, y, z); return m; };

function buildOpeningParts(op, t, mat) {
  const g = new THREE.Group();
  const frame = getMaterial(op.type === 'window' ? 'formica_white' : 'wood_oak');
  const fw = 5;
  const W = op.w, H = op.h;
  // משקוף
  g.add(at(new THREE.Mesh(new THREE.BoxGeometry(W, fw, t + 2), frame), 0, H - fw / 2, 0));
  for (const sx of [-1, 1]) g.add(at(new THREE.Mesh(new THREE.BoxGeometry(fw, H, t + 2), frame), sx * (W / 2 - fw / 2), H / 2, 0));
  if (op.type === 'window') {
    g.add(at(new THREE.Mesh(new THREE.BoxGeometry(W, fw, t + 4), frame), 0, fw / 2, 0));
    g.add(at(new THREE.Mesh(new THREE.BoxGeometry(W - fw * 2, H - fw * 2, 1), getMaterial('glass')), 0, H / 2, 0));
    g.add(at(new THREE.Mesh(new THREE.BoxGeometry(3, H - fw * 2, 3), frame), 0, H / 2, 0));
  } else if (op.type === 'door' || op.type === 'sliding') {
    const leafMat = getMaterial(op.mat || 'wood_oak');
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(W - fw * 2, H - fw, 4), leafMat);
    leaf.castShadow = true;
    const pivot = new THREE.Group();
    const open = op.type === 'sliding' ? 0 : (op.open ?? 0.35); // כמה הדלת פתוחה (רדיאנים)
    if (op.type === 'sliding') {
      leaf.position.set((W - fw * 2) * 0.35, (H - fw) / 2, t / 2 + 3);
      g.add(leaf);
    } else {
      pivot.position.set(-(W / 2 - fw), 0, (op.flip ? -1 : 1) * (t / 2 - 2));
      leaf.position.set((W - fw * 2) / 2, (H - fw) / 2, 0);
      pivot.rotation.y = (op.flip ? 1 : -1) * open;
      pivot.add(leaf);
      const handle = new THREE.Mesh(new THREE.BoxGeometry(12, 2, 3), getMaterial('metal_black'));
      handle.position.set(W - fw * 2 - 8, 100, 3); pivot.add(handle);
      g.add(pivot);
    }
  }
  g.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  return g;
}

export function buildWall(scene, w) {
  const len = wallLength(w);
  const t = w.t ?? scene.settings?.wallThick ?? 12;
  const H = w.h ?? scene.settings?.wallHeight ?? 270;
  const mat = wallMaterial(scene, w);
  const grp = new THREE.Group();
  const ang = Math.atan2(w.b[1] - w.a[1], w.b[0] - w.a[0]);
  grp.position.set(w.a[0], 0, w.a[1]);
  grp.rotation.y = -ang;
  const ext = t / 2; // הארכה בקצוות כדי שהפינות ייסגרו
  const ops = (scene.openings || []).filter((o) => o.wall === w.id)
    .map((o) => ({ ...o, s: Math.max(0, o.at - o.w / 2), e: Math.min(len, o.at + o.w / 2), sill: o.type === 'window' ? (o.sill ?? 90) : 0 }))
    .sort((p, q) => p.s - q.s);
  let cur = -ext;
  for (const o of ops) {
    if (o.s > cur) grp.add(wallBox(o.s - cur, H, t, mat, cur, 0));
    const ow = o.e - o.s;
    if (o.sill > 0) grp.add(wallBox(ow, o.sill, t, mat, o.s, 0));
    const top = o.sill + o.h;
    if (top < H) grp.add(wallBox(ow, H - top, t, mat, o.s, top));
    const parts = buildOpeningParts({ ...o, w: ow }, t, mat);
    parts.position.set(o.s + ow / 2, o.sill, 0);
    parts.userData = { kind: 'opening', id: o.id };
    parts.traverse((m) => { m.userData = { kind: 'opening', id: o.id }; });
    grp.add(parts);
    cur = Math.max(cur, o.e);
  }
  if (cur < len + ext) grp.add(wallBox(len + ext - cur, H, t, mat, cur, 0));
  grp.traverse((m) => { if (!m.userData.kind) m.userData = { kind: 'wall', id: w.id }; });
  grp.userData = { kind: 'wall', id: w.id };
  return grp;
}

export function polyArea(poly) {
  let a = 0;
  for (let i = 0; i < poly.length; i++) {
    const [x1, y1] = poly[i], [x2, y2] = poly[(i + 1) % poly.length];
    a += x1 * y2 - x2 * y1;
  }
  return Math.abs(a / 2);
}
export function polyCenter(poly) {
  let x = 0, y = 0;
  for (const p of poly) { x += p[0]; y += p[1]; }
  return [x / poly.length, y / poly.length];
}

export function buildRoom(scene, r, { ceiling = false } = {}) {
  const grp = new THREE.Group();
  if (!r.poly || r.poly.length < 3) return grp;
  const shape = new THREE.Shape(r.poly.map(([x, y]) => new THREE.Vector2(x, y)));
  const geo = new THREE.ShapeGeometry(shape);
  const key = r.floor || 'parquet_oak';
  const s = texScale(key);
  const uv = geo.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) / s, uv.getY(i) / s);
  // ShapeGeometry בנוי במישור XY — מסובבים לרצפה (XZ) עם y של התוכנית = z
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) { const x = pos.getX(i), y = pos.getY(i); pos.setXYZ(i, x, 0.6, y); }
  geo.computeVertexNormals();
  // הנורמלים צריכים לפנות למעלה
  const nrm = geo.attributes.normal;
  for (let i = 0; i < nrm.count; i++) nrm.setXYZ(i, 0, 1, 0);
  const floor = new THREE.Mesh(geo, getMaterial(key, { side: 'double' }));
  floor.receiveShadow = true;
  floor.userData = { kind: 'room', id: r.id };
  grp.add(floor);
  if (ceiling) {
    const cg = geo.clone();
    const cp = cg.attributes.position;
    const H = scene.settings?.wallHeight ?? 270;
    for (let i = 0; i < cp.count; i++) cp.setY(i, H);
    const c = new THREE.Mesh(cg, getMaterial('paint_white', { side: 'double' }));
    c.userData = { kind: 'ceiling', id: r.id };
    grp.add(c);
  }
  grp.userData = { kind: 'room', id: r.id };
  return grp;
}

export function buildItemObject(scene, it) {
  const obj = buildItem(it);
  const def = CATALOG[it.type] || {};
  obj.position.set(it.x, it.z ?? def.z ?? 0, it.y);
  if (def.z === -1 && it.z == null) obj.position.y = scene.settings?.wallHeight ?? 270;
  obj.rotation.y = -THREE.MathUtils.degToRad(it.rot || 0);
  obj.traverse((m) => { m.userData = { kind: 'item', id: it.id }; });
  obj.userData = { kind: 'item', id: it.id };
  return obj;
}

// בונה את כל המודל. מחזיר קבוצה אחת + מפה מזהה→אובייקט
export function buildScene(scene, opts = {}) {
  const root = new THREE.Group();
  const index = new Map();
  for (const r of scene.rooms || []) { const o = buildRoom(scene, r, opts); root.add(o); index.set(r.id, o); }
  for (const w of scene.walls || []) { const o = buildWall(scene, w); root.add(o); index.set(w.id, o); }
  for (const it of scene.items || []) { const o = buildItemObject(scene, it); root.add(o); index.set(it.id, o); }
  return { root, index };
}

export function sceneBounds(scene) {
  const pts = [];
  for (const w of scene.walls || []) pts.push(w.a, w.b);
  for (const r of scene.rooms || []) pts.push(...r.poly);
  for (const it of scene.items || []) pts.push([it.x, it.y]);
  if (!pts.length && scene.underlay?.segs) for (const g of scene.underlay.segs) pts.push([g[0], g[1]], [g[2], g[3]]);
  if (!pts.length) return { minX: -300, minY: -300, maxX: 300, maxY: 300 };
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const [x, y] of pts) { minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); }
  return { minX, minY, maxX, maxY };
}
