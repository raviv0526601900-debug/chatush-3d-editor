// תוכנית דו־ממדית (SVG): ציור קירות וחדרים, דלתות וחלונות, הצבת רכיבים, הזזה, מדידה
import { CATALOG, CATEGORIES } from './catalog.js';
import { swatch } from './materials.js';
import { wallLength, polyArea, polyCenter, sceneBounds } from './builder3d.js';

const NS = 'http://www.w3.org/2000/svg';
let GRID = 5;            // הצמדה לרשת (ס"מ) — נקבע לפי הגדרות המודל; Shift = 1 מ"מ
let UNITS = 'cm';         // יחידות התצוגה: mm / cm / m
const SNAP_PX = 12;      // מרחק הצמדה לנקודות קצה (פיקסלים)
const CAT_COLOR = { living: '#c9b49a', bedroom: '#b9c2cf', dining: '#cdb89b', kitchen: '#a9b8a0', bath: '#a8c4cc', carpentry: '#c4a27c', electric: '#f2b705', build: '#9a9690', decor: '#b7c79f' };

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const snapV = (v, g = GRID) => Math.round(v / g) * g;
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
// דיוק עד המילימטר, ביחידות שנבחרו בהגדרות המודל
export function setUnits(u) { UNITS = u === 'mm' || u === 'm' ? u : 'cm'; }
export const fmtNum = (v, d) => Number(v.toFixed(d)).toLocaleString('he-IL', { maximumFractionDigits: d });
export const fmtLen = (cm) => {
  if (UNITS === 'mm') return fmtNum(cm * 10, 0) + ' מ"מ';
  if (UNITS === 'm') return fmtNum(cm / 100, 3) + " מ'";
  return fmtNum(cm, 1) + ' ס"מ';
};
export const unitName = () => ({ mm: 'מ"מ', m: "מ'", cm: 'ס"מ' }[UNITS]);
export const fromUnits = (v) => (UNITS === 'mm' ? v / 10 : UNITS === 'm' ? v * 100 : v);
export const fmtArea = (cm2) => fmtNum(cm2 / 10000, 2) + ' מ"ר';
const NICE = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000];

function projectOnSeg(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const L2 = dx * dx + dy * dy || 1;
  let t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2;
  t = Math.max(0, Math.min(1, t));
  const q = [a[0] + dx * t, a[1] + dy * t];
  return { t, q, d: dist(p, q), along: t * Math.sqrt(L2) };
}

export class Plan2D {
  constructor(svg, app) {
    this.svg = svg; this.app = app;
    this.s = 0.6; this.tx = 400; this.ty = 300;
    this.drag = null; this.draft = null; this.measure = null; this.hover = null; this.typed = '';
    this.underlayOn = true;
    // שורת מיקום ומדידה חיה (לא מצריכה ציור מחדש של כל התוכנית)
    this.readout = document.createElement('div');
    this.readout.className = 'plan-readout';
    this.svg.parentElement?.appendChild(this.readout);
    svg.addEventListener('pointerdown', (e) => this.down(e));
    svg.addEventListener('pointermove', (e) => this.move(e));
    svg.addEventListener('pointerup', (e) => this.up(e));
    svg.addEventListener('dblclick', () => this.finishWall());
    svg.addEventListener('contextmenu', (e) => { e.preventDefault(); this.finishWall(); });
    svg.addEventListener('wheel', (e) => this.wheel(e), { passive: false });
    new ResizeObserver(() => this.render()).observe(svg);
  }

  // ---------- המרות
  toWorld(e) {
    const r = this.svg.getBoundingClientRect();
    return [(e.clientX - r.left - this.tx) / this.s, (e.clientY - r.top - this.ty) / this.s];
  }
  toScreen([x, y]) { return [x * this.s + this.tx, y * this.s + this.ty]; }

  fit() {
    const sc = this.app.scene;
    const b = sceneBounds(sc);
    const r = this.svg.getBoundingClientRect();
    if (!r.width) return;
    const w = Math.max(200, b.maxX - b.minX), h = Math.max(200, b.maxY - b.minY);
    this.s = Math.min((r.width - 80) / w, (r.height - 80) / h);
    this.tx = r.width / 2 - ((b.minX + b.maxX) / 2) * this.s;
    this.ty = r.height / 2 - ((b.minY + b.maxY) / 2) * this.s;
    this.render();
  }

  wheel(e) {
    e.preventDefault();
    const r = this.svg.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    const f = Math.exp(-e.deltaY * 0.0015);
    const ns = Math.max(0.05, Math.min(8, this.s * f));
    this.tx = mx - (mx - this.tx) * (ns / this.s);
    this.ty = my - (my - this.ty) * (ns / this.s);
    this.s = ns;
    this.render();
  }

  // הצמדה: נקודות קצה של קירות → זווית ישרה → רשת
  snap(p, from) {
    const sc = this.app.scene;
    let best = null, bd = SNAP_PX / this.s;
    for (const w of sc.walls) for (const q of [w.a, w.b]) {
      const d = dist(p, q);
      if (d < bd) { bd = d; best = q; }
    }
    if (best) return { p: [best[0], best[1]], snapped: 'end' };
    let q = [snapV(p[0]), snapV(p[1])];
    if (from) {
      const dx = q[0] - from[0], dy = q[1] - from[1];
      const ang = Math.atan2(dy, dx) * 180 / Math.PI;
      const k = Math.round(ang / 45) * 45;
      if (Math.abs(ang - k) < 7) {
        const L = Math.hypot(dx, dy);
        const rad = k * Math.PI / 180;
        q = [from[0] + Math.round(Math.cos(rad) * L / GRID) * GRID, from[1] + Math.round(Math.sin(rad) * L / GRID) * GRID];
        if (k % 90 === 0) { if (k % 180 === 0) q[1] = from[1]; else q[0] = from[0]; }
      }
    }
    return { p: q, snapped: 'grid' };
  }

  nearestWall(p, maxCm = 40) {
    let best = null;
    for (const w of this.app.scene.walls) {
      const pr = projectOnSeg(p, w.a, w.b);
      const lim = Math.max(maxCm, (w.t || 12) / 2 + 4);
      if (pr.d < lim && (!best || pr.d < best.d)) best = { w, ...pr };
    }
    return best;
  }

  hit(e) {
    const el = e.target.closest?.('[data-id]');
    if (!el) return null;
    return { kind: el.dataset.kind, id: el.dataset.id, handle: el.dataset.handle };
  }

  // ---------- אירועי עכבר/מגע
  setSnap(e) {
    GRID = e?.shiftKey ? 0.1 : (+this.app.scene?.settings?.snap || 5);
  }

  updateReadout() {
    const el = this.readout; if (!el || !this.app.scene) return;
    const c = this.cursor;
    const parts = [];
    if (c) parts.push(`X ${fmtLen(c[0])} · Y ${fmtLen(c[1])}`);
    if (this.draft) {
      const { a, b } = this.draft;
      const ang = (Math.atan2(-(b[1] - a[1]), b[0] - a[0]) * 180 / Math.PI + 360) % 360;
      parts.push(`<b>אורך ${fmtLen(dist(a, b))}</b> · זווית ${fmtNum(ang, 1)}°`);
    }
    if (this.measure) parts.push(`<b style="color:#e0523f">מדידה ${fmtLen(dist(this.measure.a, this.measure.b))}</b>`);
    const snapTxt = GRID < 1 ? 'חופשי (1 מ"מ)' : fmtLen(GRID);
    parts.push(`הצמדה ${snapTxt} · Shift לדיוק של מ"מ`);
    el.innerHTML = parts.join('<span class="sep">|</span>');
  }

  down(e) {
    this.setSnap(e);
    this.svg.setPointerCapture(e.pointerId);
    this.svg.focus();
    const app = this.app, sc = app.scene;
    const p = this.toWorld(e);
    const tool = app.tool;
    if (e.button === 1 || (e.button === 0 && e.altKey) || app.viewOnly) { this.drag = { type: 'pan', sx: e.clientX, sy: e.clientY, tx: this.tx, ty: this.ty }; return; }
    if (e.button === 2) return;

    if (tool === 'wall') {
      const sp = this.snap(p, this.draft?.a);
      if (!this.draft) { this.draft = { a: sp.p, b: sp.p }; this.typed = ''; app.hint('לחצו לסיום הקיר · הקלידו אורך ו-Enter · לחיצה כפולה או Esc לסיום'); }
      else this.placeWall(sp.p);
      this.render(); return;
    }
    if (tool === 'room') { const sp = this.snap(p); this.drag = { type: 'room', a: sp.p, b: sp.p }; return; }
    if (tool === 'door' || tool === 'window') {
      const nw = this.nearestWall(p);
      if (!nw) { app.toast('לחצו על קיר כדי להוסיף ' + (tool === 'door' ? 'דלת' : 'חלון')); return; }
      const L = wallLength(nw.w);
      const W = tool === 'door' ? 90 : 120;
      const at = Math.max(W / 2, Math.min(L - W / 2, snapV(nw.along)));
      const op = { id: app.newId('o'), wall: nw.w.id, type: tool, at, w: W, h: tool === 'door' ? 210 : 130, sill: tool === 'window' ? 90 : 0 };
      sc.openings.push(op);
      app.commit(tool === 'door' ? 'הוספת דלת' : 'הוספת חלון');
      app.select('opening', op.id);
      return;
    }
    if (tool === 'item') { this.placeItem(p); return; }
    if (tool === 'measure') {
      const sp = this.snap(p);
      if (!this.measure || this.measure.done) this.measure = { a: sp.p, b: sp.p, done: false };
      else { this.measure.b = sp.p; this.measure.done = true; }
      this.render(); return;
    }
    // בחירה
    const h = this.hit(e);
    if (!h) { app.select(null); this.drag = { type: 'pan', sx: e.clientX, sy: e.clientY, tx: this.tx, ty: this.ty }; return; }
    app.select(h.kind, h.id);
    if (h.kind === 'item') {
      const it = sc.items.find((x) => x.id === h.id);
      if (h.handle === 'rot') this.drag = { type: 'rot', it };
      else this.drag = { type: 'item', it, off: [p[0] - it.x, p[1] - it.y], moved: false };
    } else if (h.kind === 'wall') {
      const w = sc.walls.find((x) => x.id === h.id);
      if (h.handle === 'a' || h.handle === 'b') this.drag = { type: 'end', w, end: h.handle, joined: this.joined(w[h.handle], w) };
      else this.drag = { type: 'wall', w, p0: p, a0: [...w.a], b0: [...w.b], moved: false };
    } else if (h.kind === 'opening') {
      const op = sc.openings.find((x) => x.id === h.id);
      this.drag = { type: 'opening', op, moved: false };
    } else if (h.kind === 'room') {
      this.drag = { type: 'pan', sx: e.clientX, sy: e.clientY, tx: this.tx, ty: this.ty, click: true };
    }
  }

  // קירות אחרים שמחוברים לאותה נקודה זזים יחד
  joined(pt, self) {
    const out = [];
    for (const w of this.app.scene.walls) {
      if (w === self) continue;
      if (dist(w.a, pt) < 1) out.push([w, 'a']);
      if (dist(w.b, pt) < 1) out.push([w, 'b']);
    }
    return out;
  }

  move(e) {
    const app = this.app, sc = app.scene;
    this.setSnap(e);
    const p = this.toWorld(e);
    this.cursor = p;
    this.updateReadout();
    const d = this.drag;
    if (d?.type === 'pan') { this.tx = d.tx + (e.clientX - d.sx); this.ty = d.ty + (e.clientY - d.sy); this.render(); return; }
    if (this.draft) { this.draft.b = this.snap(p, this.draft.a).p; this.render(); return; }
    if (this.measure && !this.measure.done) { this.measure.b = this.snap(p).p; this.render(); return; }
    if (d?.type === 'room') { d.b = this.snap(p).p; this.render(); return; }
    if (d?.type === 'item') {
      d.it.x = snapV(p[0] - d.off[0]); d.it.y = snapV(p[1] - d.off[1]); d.moved = true;
      app.live(d.it); this.render(); return;
    }
    if (d?.type === 'rot') {
      const a = Math.atan2(p[1] - d.it.y, p[0] - d.it.x) * 180 / Math.PI - 90;
      d.it.rot = (Math.round(a / 15) * 15 + 360) % 360; d.moved = true;
      app.live(d.it); this.render(); return;
    }
    if (d?.type === 'end') {
      const q = this.snap(p, d.end === 'a' ? d.w.b : d.w.a).p;
      d.w[d.end] = q; for (const [w, k] of d.joined) w[k] = [...q];
      d.moved = true; this.render(); return;
    }
    if (d?.type === 'wall') {
      const dx = snapV(p[0] - d.p0[0]), dy = snapV(p[1] - d.p0[1]);
      d.w.a = [d.a0[0] + dx, d.a0[1] + dy]; d.w.b = [d.b0[0] + dx, d.b0[1] + dy];
      d.moved = true; this.render(); return;
    }
    if (d?.type === 'opening') {
      const w = sc.walls.find((x) => x.id === d.op.wall);
      if (w) {
        const pr = projectOnSeg(p, w.a, w.b);
        const L = wallLength(w);
        d.op.at = Math.max(d.op.w / 2, Math.min(L - d.op.w / 2, snapV(pr.along)));
        d.moved = true; this.render();
      }
      return;
    }
    if (app.tool === 'door' || app.tool === 'window' || app.tool === 'item') { this.render(); }
  }

  up(e) {
    const app = this.app, sc = app.scene, d = this.drag;
    this.drag = null;
    if (!d) return;
    if (d.type === 'room') {
      const [x1, y1] = d.a, [x2, y2] = d.b;
      if (Math.abs(x2 - x1) >= 50 && Math.abs(y2 - y1) >= 50) this.addRoomRect(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2));
      this.render(); return;
    }
    if (d.moved) {
      const labels = { item: 'הזזת רכיב', rot: 'סיבוב רכיב', end: 'עריכת קיר', wall: 'הזזת קיר', opening: 'הזזת פתח' };
      app.commit(labels[d.type] || 'עריכה');
    }
  }

  // ---------- פעולות
  placeWall(b) {
    const app = this.app;
    const a = this.draft.a;
    if (dist(a, b) < 10) { this.finishWall(); return; }
    app.scene.walls.push({ id: app.newId('w'), a: [...a], b: [...b], t: app.scene.settings.wallThick || 12, mat: 'paint_white', kind: app.scene.settings.marks ? 'new' : 'existing' });
    app.commit('ציור קיר');
    this.draft = { a: [...b], b: [...b] };
    this.typed = '';
  }
  finishWall() {
    if (this.draft) { this.draft = null; this.typed = ''; this.app.hint(''); this.render(); }
  }
  typeKey(k) {
    if (!this.draft) return false;
    if (/^[0-9.]$/.test(k)) { this.typed += k; this.app.hint(`אורך: ${this.typed} ${unitName()} · Enter לאישור`); return true; }
    if (k === 'Backspace') { this.typed = this.typed.slice(0, -1); this.app.hint(`אורך: ${this.typed || '—'} ${unitName()}`); return true; }
    if (k === 'Enter' && this.typed) {
      const L = fromUnits(parseFloat(this.typed));
      const { a, b } = this.draft;
      let dx = b[0] - a[0], dy = b[1] - a[1];
      const n = Math.hypot(dx, dy) || 1;
      if (n < 1) { dx = 1; dy = 0; }
      this.placeWall([a[0] + (dx / (n || 1)) * L, a[1] + (dy / (n || 1)) * L]);
      this.render(); return true;
    }
    if (k === 'Escape') { this.finishWall(); return true; }
    return false;
  }

  covered(a, b) {
    for (const w of this.app.scene.walls) {
      const pa = projectOnSeg(a, w.a, w.b), pb = projectOnSeg(b, w.a, w.b);
      if (pa.d < 3 && pb.d < 3) return true;
    }
    return false;
  }

  addRoomRect(x1, y1, x2, y2) {
    const app = this.app, sc = app.scene;
    const pts = [[x1, y1], [x2, y1], [x2, y2], [x1, y2]];
    for (let i = 0; i < 4; i++) {
      const a = pts[i], b = pts[(i + 1) % 4];
      if (!this.covered(a, b)) sc.walls.push({ id: app.newId('w'), a, b, t: sc.settings.wallThick || 12, mat: 'paint_white', kind: sc.settings.marks ? 'new' : 'existing' });
    }
    const r = { id: app.newId('r'), name: 'חדר ' + (sc.rooms.length + 1), poly: pts, floor: 'parquet_oak' };
    sc.rooms.push(r);
    app.commit('הוספת חדר');
    app.select('room', r.id);
  }

  placeItem(p) {
    const app = this.app, sc = app.scene;
    const type = app.itemType;
    const def = CATALOG[type];
    if (!def) { app.toast('בחרו רכיב מהרשימה'); return; }
    const it = { id: app.newId('i'), type, x: snapV(p[0]), y: snapV(p[1]), rot: 0, w: def.w, d: def.d, h: def.h };
    // צמוד לקיר הקרוב: הגב לקיר, החזית לחדר
    const nw = this.nearestWall(p, 70);
    if (nw) {
      const w = nw.w, t = w.t || 12;
      const ang = Math.atan2(w.b[1] - w.a[1], w.b[0] - w.a[0]);
      let nx = -Math.sin(ang), ny = Math.cos(ang);
      if ((p[0] - nw.q[0]) * nx + (p[1] - nw.q[1]) * ny < 0) { nx = -nx; ny = -ny; }
      const off = t / 2 + it.d / 2 + (def.elec ? -it.d / 2 + 1 : 0);
      it.x = Math.round(nw.q[0] + nx * off); it.y = Math.round(nw.q[1] + ny * off);
      it.rot = Math.round((Math.atan2(ny, nx) * 180 / Math.PI - 90 + 360) % 360);
    }
    sc.items.push(it);
    app.commit('הוספת ' + def.name);
    app.select('item', it.id);
  }

  // ---------- ציור
  render() {
    const app = this.app, sc = app.scene;
    if (!sc) return;
    const r = this.svg.getBoundingClientRect();
    const s = this.s, sel = app.sel || {};
    const W = r.width, H = r.height;
    const out = [];
    setUnits(sc.settings?.units);
    // רשת מותאמת לזום: קו ראשי כל "צעד" (לפחות 70 פיקסלים), ומשנה כל חמישית/עשירית ממנו
    const step = NICE.find((v) => v * s >= 70) || 10000;
    const minor = step / (String(step)[0] === '1' ? 10 : 5);
    const g0x = this.tx % (minor * s), g0y = this.ty % (minor * s);
    out.push(`<defs><pattern id="gm" width="${minor * s}" height="${minor * s}" patternUnits="userSpaceOnUse" x="${g0x}" y="${g0y}"><path d="M ${minor * s} 0 L 0 0 0 ${minor * s}" fill="none" stroke="${minor * s >= 7 ? '#ece4d8' : 'transparent'}" stroke-width="1"/></pattern>
      <pattern id="gM" width="${step * s}" height="${step * s}" patternUnits="userSpaceOnUse" x="${this.tx % (step * s)}" y="${this.ty % (step * s)}"><rect width="100%" height="100%" fill="url(#gm)"/><path d="M ${step * s} 0 L 0 0 0 ${step * s}" fill="none" stroke="#e0d4c3" stroke-width="1"/></pattern>
      <pattern id="hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="8" stroke="#e0523f" stroke-width="3"/></pattern></defs>`);
    out.push(`<rect width="${W}" height="${H}" fill="url(#gM)"/>`);
    out.push(`<g transform="matrix(${s} 0 0 ${s} ${this.tx} ${this.ty})">`);
    // שרטוט רקע מיובא
    if (sc.underlay?.segs?.length && this.underlayOn) {
      let d = '';
      for (const [x1, y1, x2, y2] of sc.underlay.segs) d += `M${x1} ${y1}L${x2} ${y2}`;
      out.push(`<path d="${d}" stroke="#7a8fb0" stroke-width="1" vector-effect="non-scaling-stroke" fill="none" opacity=".7"/>`);
    }
    // חדרים
    for (const rm of sc.rooms) {
      const on = sel.kind === 'room' && sel.id === rm.id;
      out.push(`<polygon data-kind="room" data-id="${rm.id}" points="${rm.poly.map((p) => p.join(',')).join(' ')}" fill="${swatch(rm.floor)}" fill-opacity="${on ? 0.55 : 0.32}" stroke="${on ? '#2f7de1' : 'none'}" stroke-width="2" vector-effect="non-scaling-stroke"/>`);
    }
    // קירות
    for (const w of sc.walls) {
      const on = sel.kind === 'wall' && sel.id === w.id;
      const t = w.t || 12;
      const col = w.kind === 'demolish' ? 'url(#hatch)' : w.kind === 'new' ? '#3f7fe0' : '#3b322b';
      out.push(`<line data-kind="wall" data-id="${w.id}" x1="${w.a[0]}" y1="${w.a[1]}" x2="${w.b[0]}" y2="${w.b[1]}" stroke="${col}" stroke-width="${t}" stroke-linecap="square" ${w.kind === 'demolish' ? 'stroke-opacity=".9"' : ''}/>`);
      if (w.kind === 'demolish') out.push(`<line x1="${w.a[0]}" y1="${w.a[1]}" x2="${w.b[0]}" y2="${w.b[1]}" stroke="#e0523f" stroke-width="${t}" stroke-linecap="square" fill="none" stroke-opacity=".25" pointer-events="none"/>`);
      if (on) out.push(`<line x1="${w.a[0]}" y1="${w.a[1]}" x2="${w.b[0]}" y2="${w.b[1]}" stroke="#2f7de1" stroke-width="${t + 6 / s}" stroke-opacity=".35" stroke-linecap="square" pointer-events="none"/>`);
    }
    // פתחים
    for (const op of sc.openings) {
      const w = sc.walls.find((x) => x.id === op.wall); if (!w) continue;
      const L = wallLength(w), t = w.t || 12;
      const ux = (w.b[0] - w.a[0]) / L, uy = (w.b[1] - w.a[1]) / L, nx = -uy, ny = ux;
      const s0 = op.at - op.w / 2, s1 = op.at + op.w / 2;
      const p0 = [w.a[0] + ux * s0, w.a[1] + uy * s0], p1 = [w.a[0] + ux * s1, w.a[1] + uy * s1];
      const on = sel.kind === 'opening' && sel.id === op.id;
      const stroke = on ? '#2f7de1' : '#3b322b';
      out.push(`<g data-kind="opening" data-id="${op.id}">`);
      out.push(`<line x1="${p0[0]}" y1="${p0[1]}" x2="${p1[0]}" y2="${p1[1]}" stroke="#fbf8f3" stroke-width="${t + 1}"/>`);
      if (op.type === 'window') {
        for (const k of [-t / 4, 0, t / 4]) out.push(`<line x1="${p0[0] + nx * k}" y1="${p0[1] + ny * k}" x2="${p1[0] + nx * k}" y2="${p1[1] + ny * k}" stroke="${stroke}" stroke-width="${k ? 1 : 2}" vector-effect="non-scaling-stroke"/>`);
      } else if (op.type === 'door') {
        const sg = op.flip ? -1 : 1;
        const tip = [p0[0] + nx * op.w * sg, p0[1] + ny * op.w * sg];
        out.push(`<line x1="${p0[0]}" y1="${p0[1]}" x2="${tip[0]}" y2="${tip[1]}" stroke="${stroke}" stroke-width="2" vector-effect="non-scaling-stroke"/>`);
        out.push(`<path d="M${tip[0]} ${tip[1]} A ${op.w} ${op.w} 0 0 ${sg > 0 ? 0 : 1} ${p1[0]} ${p1[1]}" fill="none" stroke="${stroke}" stroke-width="1" stroke-dasharray="4 3" vector-effect="non-scaling-stroke"/>`);
      } else if (op.type === 'sliding') {
        out.push(`<line x1="${p0[0] + nx * 3}" y1="${p0[1] + ny * 3}" x2="${(p0[0] + p1[0]) / 2 + nx * 3}" y2="${(p0[1] + p1[1]) / 2 + ny * 3}" stroke="${stroke}" stroke-width="3" vector-effect="non-scaling-stroke"/>`);
      }
      out.push(`<line x1="${p0[0]}" y1="${p0[1]}" x2="${p1[0]}" y2="${p1[1]}" stroke="transparent" stroke-width="${t + 10}"/>`);
      out.push(`</g>`);
    }
    // רכיבים (הנבחר מצויר אחרון, כדי שהידיות שלו תמיד יהיו מעל)
    for (const it of [...sc.items].sort((a, b) => (a.id === sel.id) - (b.id === sel.id))) {
      const def = CATALOG[it.type] || {};
      const w = it.w ?? def.w, d = it.d ?? def.d;
      const on = sel.kind === 'item' && sel.id === it.id;
      const col = CAT_COLOR[def.cat] || '#bbb';
      out.push(`<g data-kind="item" data-id="${it.id}" transform="translate(${it.x} ${it.y}) rotate(${it.rot || 0})">`);
      if (def.elec || def.light) {
        const rr = Math.max(9, Math.min(w, 30) / 2);
        out.push(`<circle r="${rr}" fill="${def.light ? '#fff3c4' : '#fff'}" stroke="${on ? '#2f7de1' : '#b48a00'}" stroke-width="${on ? 3 : 1.5}" vector-effect="non-scaling-stroke"/>`);
      } else {
        out.push(`<rect x="${-w / 2}" y="${-d / 2}" width="${w}" height="${d}" rx="${Math.min(4, w / 8)}" fill="${col}" fill-opacity=".82" stroke="${on ? '#2f7de1' : '#6d5c4c'}" stroke-width="${on ? 3 : 1}" vector-effect="non-scaling-stroke"/>`);
        out.push(`<line x1="${-w / 2 + 3}" y1="${d / 2 - 3}" x2="${w / 2 - 3}" y2="${d / 2 - 3}" stroke="#6d5c4c" stroke-width="2" vector-effect="non-scaling-stroke" opacity=".6"/>`);
      }
      if (on && !app.viewOnly) out.push(`<circle data-kind="item" data-id="${it.id}" data-handle="rot" cx="0" cy="${d / 2 + 22 / s}" r="${7 / s}" fill="#2f7de1" stroke="#fff" stroke-width="2" vector-effect="non-scaling-stroke" style="cursor:grab"/>`);
      out.push(`</g>`);
    }
    // ידיות קצה לקיר נבחר
    if (sel.kind === 'wall' && !app.viewOnly) {
      const w = sc.walls.find((x) => x.id === sel.id);
      if (w) for (const k of ['a', 'b']) out.push(`<circle data-kind="wall" data-id="${w.id}" data-handle="${k}" cx="${w[k][0]}" cy="${w[k][1]}" r="${7 / s}" fill="#fff" stroke="#2f7de1" stroke-width="3" vector-effect="non-scaling-stroke" style="cursor:move"/>`);
    }
    // טיוטות
    if (this.draft) out.push(`<line x1="${this.draft.a[0]}" y1="${this.draft.a[1]}" x2="${this.draft.b[0]}" y2="${this.draft.b[1]}" stroke="#2f7de1" stroke-opacity=".7" stroke-width="${sc.settings.wallThick || 12}" stroke-linecap="square"/>`);
    if (this.drag?.type === 'room') {
      const [x1, y1] = this.drag.a, [x2, y2] = this.drag.b;
      out.push(`<rect x="${Math.min(x1, x2)}" y="${Math.min(y1, y2)}" width="${Math.abs(x2 - x1)}" height="${Math.abs(y2 - y1)}" fill="#2f7de1" fill-opacity=".1" stroke="#2f7de1" stroke-width="2" stroke-dasharray="6 4" vector-effect="non-scaling-stroke"/>`);
    }
    if ((app.tool === 'door' || app.tool === 'window') && this.cursor) {
      const nw = this.nearestWall(this.cursor);
      if (nw) out.push(`<circle cx="${nw.q[0]}" cy="${nw.q[1]}" r="${8 / s}" fill="#2f7de1" fill-opacity=".5" pointer-events="none"/>`);
    }
    out.push('</g>');

    // שכבת טקסט (בגודל קבוע)
    const lab = (p, txt, cls = '', dy = 0) => { const [x, y] = this.toScreen(p); return `<text x="${x}" y="${y + dy}" class="${cls}" text-anchor="middle">${esc(txt)}</text>`; };
    out.push('<g class="labels" font-family="Heebo" pointer-events="none" direction="rtl">');
    // חדרים: שם, שטח ומידות חוץ — תמיד
    for (const rm of sc.rooms) {
      const c = polyCenter(rm.poly);
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const [x, y] of rm.poly) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
      const big = Math.min(x1 - x0, y1 - y0) * s;
      if (big < 26) continue;
      const fs = big > 120 ? 13 : 11;
      out.push(lab(c, rm.name, 'rl', -4).replace('<text', `<text font-size="${fs}" font-weight="700" fill="#3b322b"`));
      out.push(lab(c, fmtArea(polyArea(rm.poly)), '', fs + 1).replace('<text', `<text font-size="${fs - 1}" font-weight="700" fill="#6d5c4c"`));
      if (big > 70) out.push(lab(c, `${fmtLen(x1 - x0)} × ${fmtLen(y1 - y0)}`, '', fs * 2 + 2).replace('<text', '<text font-size="10" fill="#8a7b6c"'));
    }
    // קווי מידה לכל קיר (סגנון אדריכלי): קווי עזר, סימוני קצה ומספר לאורך הקיר
    const dimLine = (a, b, off, txt, col, bold, fs = 10.5) => {
      const [ax, ay] = this.toScreen(a), [bx, by] = this.toScreen(b);
      const Ls = Math.hypot(bx - ax, by - ay); if (Ls < 26) return '';
      const ux = (bx - ax) / Ls, uy = (by - ay) / Ls, nx = -uy, ny = ux;
      const p0 = [ax + nx * off, ay + ny * off], p1 = [bx + nx * off, by + ny * off];
      const tk = 4;
      let ang = Math.atan2(uy, ux) * 180 / Math.PI; if (ang > 90 || ang <= -90) ang += 180;
      const mx = (p0[0] + p1[0]) / 2 + nx * 7, my = (p0[1] + p1[1]) / 2 + ny * 7;
      const showTxt = Ls > txt.length * 5.6 + 10;
      return `<g stroke="${col}" stroke-width="1"><line x1="${ax + nx * 3}" y1="${ay + ny * 3}" x2="${p0[0] + nx * 3}" y2="${p0[1] + ny * 3}" opacity=".55"/><line x1="${bx + nx * 3}" y1="${by + ny * 3}" x2="${p1[0] + nx * 3}" y2="${p1[1] + ny * 3}" opacity=".55"/><line x1="${p0[0]}" y1="${p0[1]}" x2="${p1[0]}" y2="${p1[1]}"/><line x1="${p0[0] - (ux + nx) * tk}" y1="${p0[1] - (uy + ny) * tk}" x2="${p0[0] + (ux + nx) * tk}" y2="${p0[1] + (uy + ny) * tk}" stroke-width="1.4"/><line x1="${p1[0] - (ux + nx) * tk}" y1="${p1[1] - (uy + ny) * tk}" x2="${p1[0] + (ux + nx) * tk}" y2="${p1[1] + (uy + ny) * tk}" stroke-width="1.4"/></g>`
        + (showTxt ? `<text x="${mx}" y="${my}" transform="rotate(${ang} ${mx} ${my})" text-anchor="middle" dominant-baseline="middle" font-size="${fs}" font-weight="${bold ? 800 : 600}" fill="${col}" paint-order="stroke" stroke="#fbf8f3" stroke-width="3">${esc(txt)}</text>` : '');
    };
    const bnd = sc.walls.length ? sceneBounds({ walls: sc.walls }) : null;
    const ctr = bnd ? [(bnd.minX + bnd.maxX) / 2, (bnd.minY + bnd.maxY) / 2] : [0, 0];
    for (const w of sc.walls) {
      const L = wallLength(w); if (L < 1) continue;
      const on = sel.kind === 'wall' && sel.id === w.id;
      // קו המידה בצד החיצוני של הקיר (הרחוק ממרכז התוכנית)
      const m = [(w.a[0] + w.b[0]) / 2, (w.a[1] + w.b[1]) / 2];
      const nx = -(w.b[1] - w.a[1]) / L, ny = (w.b[0] - w.a[0]) / L;
      const outSide = (m[0] - ctr[0]) * nx + (m[1] - ctr[1]) * ny >= 0 ? 1 : -1;
      const off = outSide * ((w.t || 12) / 2 * s + 12);
      // קירות פנימיים: המידה מופיעה בזום קרוב או כשהקיר נבחר — כדי שלא תסתיר שמות ושטחי חדרים
      const edge = bnd && Math.min(Math.abs(m[0] - bnd.minX), Math.abs(m[0] - bnd.maxX), Math.abs(m[1] - bnd.minY), Math.abs(m[1] - bnd.maxY)) < (w.t || 12) + 20;
      if (!edge && !on && s < 0.85) continue;
      out.push(dimLine(w.a, w.b, off, fmtLen(L), on ? '#2f7de1' : edge ? '#8a7b6c' : '#a5957f', on));
    }
    // מידות כוללות של המבנה (למעלה ומשמאל)
    if (bnd && sc.walls.length > 1) {
      const pad = 44;
      const [, topY] = this.toScreen([0, bnd.minY]);
      const [leftX] = this.toScreen([bnd.minX, 0]);
      const wpx = (bnd.maxX - bnd.minX) * s, hpx = (bnd.maxY - bnd.minY) * s;
      if (wpx > 40) out.push(dimLine([bnd.maxX, bnd.minY], [bnd.minX, bnd.minY], pad, `סה"כ ${fmtLen(bnd.maxX - bnd.minX)}`, '#3b322b', true, 11.5));
      if (hpx > 40) out.push(dimLine([bnd.minX, bnd.minY], [bnd.minX, bnd.maxY], pad, `סה"כ ${fmtLen(bnd.maxY - bnd.minY)}`, '#3b322b', true, 11.5));
      void topY; void leftX;
    }
    if (s > 0.9) for (const it of sc.items) {
      const def = CATALOG[it.type]; if (!def || def.elec) continue;
      out.push(lab([it.x, it.y], def.name, '', 4).replace('<text', '<text font-size="10" fill="#3b322b" opacity=".75"'));
    }
    if (this.draft) {
      const L = dist(this.draft.a, this.draft.b);
      out.push(lab([(this.draft.a[0] + this.draft.b[0]) / 2, (this.draft.a[1] + this.draft.b[1]) / 2], fmtLen(L), '', -12).replace('<text', '<text font-size="13" font-weight="800" fill="#2f7de1"'));
    }
    if (this.drag?.type === 'room') {
      const [x1, y1] = this.drag.a, [x2, y2] = this.drag.b;
      out.push(lab([(x1 + x2) / 2, (y1 + y2) / 2], `${fmtLen(Math.abs(x2 - x1))} × ${fmtLen(Math.abs(y2 - y1))}`, '', 0).replace('<text', '<text font-size="13" font-weight="800" fill="#2f7de1"'));
    }
    if (this.measure) {
      const { a, b } = this.measure;
      const [ax, ay] = this.toScreen(a), [bx, by] = this.toScreen(b);
      out.push(`<line x1="${ax}" y1="${ay}" x2="${bx}" y2="${by}" stroke="#e0523f" stroke-width="2" stroke-dasharray="6 4"/><circle cx="${ax}" cy="${ay}" r="4" fill="#e0523f"/><circle cx="${bx}" cy="${by}" r="4" fill="#e0523f"/>`);
      out.push(lab([(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], fmtLen(dist(a, b)), '', -10).replace('<text', '<text font-size="14" font-weight="800" fill="#e0523f"'));
    }
    out.push('</g>');
    // סרגלים: למעלה ומשמאל, במטרים מנקודת האפס של המודל
    const rl = [];
    rl.push(`<rect x="0" y="0" width="${W}" height="20" fill="#fbf8f3" fill-opacity=".94"/><rect x="0" y="0" width="30" height="${H}" fill="#fbf8f3" fill-opacity=".94"/><line x1="0" y1="20" x2="${W}" y2="20" stroke="#d9cdbd"/><line x1="30" y1="0" x2="30" y2="${H}" stroke="#d9cdbd"/>`);
    const mlab = (v) => fmtNum(v / 100, step < 100 ? 2 : step < 1000 ? 1 : 0);
    for (let v = Math.floor(-this.tx / s / step) * step; v * s + this.tx < W; v += step) {
      const x = v * s + this.tx; if (x < 30) continue;
      rl.push(`<line x1="${x}" y1="12" x2="${x}" y2="20" stroke="#8a7b6c"/><text x="${x + 3}" y="11" font-size="9.5" fill="#6d5c4c">${mlab(v)}</text>`);
      for (let k = 1; k < 5; k++) { const xm = x + k * step * s / 5; if (xm < W) rl.push(`<line x1="${xm}" y1="16" x2="${xm}" y2="20" stroke="#b9ab98"/>`); }
    }
    for (let v = Math.floor(-this.ty / s / step) * step; v * s + this.ty < H; v += step) {
      const y = v * s + this.ty; if (y < 20) continue;
      rl.push(`<line x1="22" y1="${y}" x2="30" y2="${y}" stroke="#8a7b6c"/><text x="15" y="${y + 3}" font-size="9.5" fill="#6d5c4c" text-anchor="middle" transform="rotate(-90 15 ${y + 3})">${mlab(v)}</text>`);
      for (let k = 1; k < 5; k++) { const ym = y + k * step * s / 5; if (ym < H) rl.push(`<line x1="26" y1="${ym}" x2="30" y2="${ym}" stroke="#b9ab98"/>`); }
    }
    rl.push(`<text x="15" y="14" font-size="9" fill="#8a7b6c" text-anchor="middle">מ'</text>`);
    out.push(`<g font-family="Heebo" pointer-events="none" direction="rtl">${rl.join('')}</g>`);
    // קנה מידה לפי הזום
    const bar = step * s;
    out.push(`<g transform="translate(${W - 24 - bar} ${H - 22})" pointer-events="none"><rect width="${bar}" height="5" fill="#3b322b" rx="2"/><rect width="${bar / 2}" height="5" fill="#fbf8f3" stroke="#3b322b" rx="2"/><text x="${bar / 2}" y="-6" font-size="10" text-anchor="middle" fill="#6d5c4c" font-family="Heebo" direction="rtl">${esc(fmtLen(step))}</text></g>`);
    this.svg.innerHTML = out.join('');
    this.updateReadout();
    this.svg.style.cursor = { wall: 'crosshair', room: 'crosshair', door: 'copy', window: 'copy', item: 'copy', measure: 'crosshair' }[app.tool] || (this.drag?.type === 'pan' ? 'grabbing' : 'default');
  }

  // ייצוא התוכנית כ-SVG עצמאי
  exportSVG() {
    const prev = [this.s, this.tx, this.ty];
    const sc = this.app.scene;
    const b = sceneBounds(sc);
    const pad = 80, scale = 1;
    const W = (b.maxX - b.minX) * scale + pad * 2, H = (b.maxY - b.minY) * scale + pad * 2;
    this.s = scale; this.tx = pad - b.minX * scale; this.ty = pad - b.minY * scale;
    const sel = this.app.sel; this.app.sel = null;
    this.svg.getBoundingClientRect = () => ({ width: W, height: H, left: 0, top: 0 });
    this.render();
    const svg = `<svg xmlns="${NS}" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" direction="rtl">${this.svg.innerHTML}</svg>`;
    delete this.svg.getBoundingClientRect;
    this.app.sel = sel;
    [this.s, this.tx, this.ty] = prev;
    this.render();
    return svg;
  }
}

export { CATEGORIES };
