// תצוגה תלת־ממדית: מצלמה, תאורה, בחירה, הזזת רכיבים, סיור בגובה העיניים, צילום וייצוא
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { buildScene, buildItemObject, sceneBounds, polyCenter } from './builder3d.js';

export class View3D {
  constructor(el, app) {
    this.el = el; this.app = app;
    const r = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    r.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.18;
    r.outputColorSpace = THREE.SRGBColorSpace;
    el.appendChild(r.domElement);
    this.renderer = r;
    const s = new THREE.Scene();
    s.background = new THREE.Color('#efe7dc');
    s.fog = new THREE.Fog('#efe7dc', 4000, 9000);
    this.scene = s;
    this.camera = new THREE.PerspectiveCamera(45, 1, 5, 20000);
    this.camera.position.set(800, 1100, 1300);
    this.controls = new OrbitControls(this.camera, r.domElement);
    this.controls.enableDamping = true; this.controls.dampingFactor = 0.08;
    this.controls.maxPolarAngle = Math.PI * 0.495;
    this.controls.screenSpacePanning = true;
    // תאורה
    s.add(new THREE.HemisphereLight('#fffaf2', '#b9a891', 1.15));
    const sun = new THREE.DirectionalLight('#fff3e0', 2.0);
    sun.position.set(-900, 1800, -700); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera; sc.left = -1500; sc.right = 1500; sc.top = 1500; sc.bottom = -1500; sc.near = 100; sc.far = 5000;
    sun.shadow.bias = -0.0004; sun.shadow.normalBias = 1.5;
    s.add(sun); s.add(sun.target); this.sun = sun;
    const fill = new THREE.DirectionalLight('#dfe8ff', 0.45); fill.position.set(900, 700, 1200); s.add(fill);
    // קרקע
    const ground = new THREE.Mesh(new THREE.CircleGeometry(6000, 64), new THREE.MeshStandardMaterial({ color: '#e6dccd', roughness: 1 }));
    ground.rotation.x = -Math.PI / 2; ground.position.y = -1; ground.receiveShadow = true;
    s.add(ground); this.ground = ground;
    this.root = null; this.index = new Map();
    this.selBox = new THREE.Box3Helper(new THREE.Box3(), new THREE.Color('#2f7de1'));
    this.selBox.visible = false; s.add(this.selBox);
    // הזזה ישירה בתלת־ממד
    this.tc = new TransformControls(this.camera, r.domElement);
    this.tc.setSpace('world'); this.tc.showY = false; this.tc.setTranslationSnap(5); this.tc.setRotationSnap(THREE.MathUtils.degToRad(15));
    this.tc.addEventListener('dragging-changed', (e) => {
      this.controls.enabled = !e.value;
      if (!e.value && this.tcItem) this.app.commit('הזזת רכיב בתלת־ממד');
    });
    this.tc.addEventListener('objectChange', () => {
      const it = this.tcItem, o = this.tc.object; if (!it || !o) return;
      it.x = Math.round(o.position.x); it.y = Math.round(o.position.z);
      it.rot = Math.round((-THREE.MathUtils.radToDeg(o.rotation.y) + 360) % 360);
      this.app.live(it, { from3d: true });
    });
    this.tcHelper = this.tc.getHelper ? this.tc.getHelper() : this.tc;
    s.add(this.tcHelper);
    // בחירה בלחיצה
    this.ray = new THREE.Raycaster();
    let downAt = null;
    r.domElement.addEventListener('pointerdown', (e) => { downAt = [e.clientX, e.clientY]; });
    r.domElement.addEventListener('pointerup', (e) => {
      if (!downAt || Math.hypot(e.clientX - downAt[0], e.clientY - downAt[1]) > 4 || this.tc.dragging || this.walking) return;
      this.pick(e);
    });
    // סיור
    this.walking = false; this.keys = new Set(); this.yaw = 0; this.pitch = 0;
    window.addEventListener('keydown', (e) => { if (this.walking) { this.keys.add(e.key.toLowerCase()); if (e.key === 'Escape') this.setWalk(false); } });
    window.addEventListener('keyup', (e) => this.keys.delete(e.key.toLowerCase()));
    let look = null;
    r.domElement.addEventListener('pointerdown', (e) => { if (this.walking) look = [e.clientX, e.clientY, this.yaw, this.pitch]; });
    window.addEventListener('pointermove', (e) => { if (this.walking && look) { this.yaw = look[2] - (e.clientX - look[0]) * 0.005; this.pitch = Math.max(-1.2, Math.min(1.2, look[3] - (e.clientY - look[1]) * 0.005)); } });
    window.addEventListener('pointerup', () => { look = null; });
    new ResizeObserver(() => this.resize()).observe(el);
    this.clock = new THREE.Clock();
    const loop = () => { requestAnimationFrame(loop); this.tick(); };
    loop();
  }

  resize() {
    const w = this.el.clientWidth, h = this.el.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = w + 'px'; this.renderer.domElement.style.height = h + 'px';
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
  }

  tick() {
    const dt = Math.min(0.05, this.clock.getDelta());
    if (this.walking) {
      const sp = (this.keys.has('shift') ? 320 : 160) * dt;
      const f = new THREE.Vector3(Math.sin(this.yaw) * -1, 0, Math.cos(this.yaw) * -1);
      const rt = new THREE.Vector3(-f.z, 0, f.x);
      const k = this.keys, p = this.camera.position;
      if (k.has('w') || k.has('arrowup')) p.addScaledVector(f, sp);
      if (k.has('s') || k.has('arrowdown')) p.addScaledVector(f, -sp);
      if (k.has('a') || k.has('arrowleft')) p.addScaledVector(rt, -sp);
      if (k.has('d') || k.has('arrowright')) p.addScaledVector(rt, sp);
      p.y = 165;
      this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
    } else this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  rebuild(sceneData, keepCamera = true) {
    if (this.root) {
      this.scene.remove(this.root);
      this.root.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
    }
    const { root, index } = buildScene(sceneData, { ceiling: this.ceiling || this.walking });
    this.root = root; this.index = index;
    this.scene.add(root);
    const b = sceneBounds(sceneData);
    // רשת מטרים על הרצפה (משבצת = 1 מ', קו כהה כל 5 מ')
    if (this.grid) { this.scene.remove(this.grid); this.grid.geometry.dispose(); }
    if (this.grid5) { this.scene.remove(this.grid5); this.grid5.geometry.dispose(); }
    const gsize = Math.ceil((Math.max(b.maxX - b.minX, b.maxY - b.minY) + 600) / 500) * 500;
    this.grid = new THREE.GridHelper(gsize, gsize / 100, '#bfae98', '#c9b9a4');
    this.grid5 = new THREE.GridHelper(gsize, gsize / 500, '#a8987f', '#a8987f');
    for (const g of [this.grid, this.grid5]) {
      g.position.set((b.minX + b.maxX) / 2, g === this.grid ? 0.4 : 0.6, (b.minY + b.maxY) / 2);
      g.material.transparent = true; g.material.opacity = g === this.grid ? 0.8 : 0.75; g.material.depthWrite = false;
      this.scene.add(g);
    }
    const cx = (b.minX + b.maxX) / 2, cz = (b.minY + b.maxY) / 2;
    this.sun.target.position.set(cx, 0, cz);
    this.sun.position.set(cx - 900, 1800, cz - 700);
    const span = Math.max(b.maxX - b.minX, b.maxY - b.minY, 600);
    const shc = this.sun.shadow.camera; shc.left = shc.bottom = -span; shc.right = shc.top = span; shc.updateProjectionMatrix();
    if (!keepCamera) this.fit(sceneData);
    this.updateSelection();
  }

  // עדכון חי של רכיב אחד (בזמן גרירה) בלי לבנות הכל מחדש
  liveItem(sceneData, it) {
    const old = this.index.get(it.id);
    if (old && this.tc.object === old && this.tc.dragging) { this.updateSelection(); return; }
    if (old) this.root.remove(old);
    const o = buildItemObject(sceneData, it);
    this.root.add(o); this.index.set(it.id, o);
    this.updateSelection();
  }

  fit(sceneData, mode = this.camMode || 'persp') {
    const b = sceneBounds(sceneData);
    const cx = (b.minX + b.maxX) / 2, cz = (b.minY + b.maxY) / 2;
    // במסך צר (טלפון לאורך) מתרחקים יותר כדי שכל המודל ייכנס
    const span = Math.max(b.maxX - b.minX, b.maxY - b.minY, 400) * Math.max(1, 1.3 / (this.camera.aspect || 1));
    this.controls.target.set(cx, 60, cz);
    if (mode === 'top') this.camera.position.set(cx, span * 1.55, cz + 1);
    else this.camera.position.set(cx + span * 0.62, span * 1.12, cz + span * 1.2);
    this.camera.lookAt(this.controls.target);
    this.controls.update();
  }

  setCam(mode, sceneData) { this.camMode = mode; this.setWalk(false); this.fit(sceneData, mode); }

  setWalk(on, sceneData) {
    if (on === this.walking) return;
    this.walking = on;
    this.el.parentElement.classList.toggle('walking', on);
    this.controls.enabled = !on;
    this.tc.detach();
    if (on) {
      const sc = sceneData || this.app.scene;
      const room = sc.rooms[0];
      const c = room ? polyCenter(room.poly) : [0, 0];
      this.camera.position.set(c[0], 165, c[1]);
      this.yaw = 0; this.pitch = 0;
      this.rebuild(sc);
    } else {
      this.rebuild(this.app.scene);
      this.fit(this.app.scene);
    }
  }

  flyToRoom(room) {
    const c = polyCenter(room.poly);
    this.setWalk(false);
    this.controls.target.set(c[0], 80, c[1]);
    this.camera.position.set(c[0] + 220, 420, c[1] + 380);
    this.controls.update();
  }

  pick(e) {
    if (!this.root) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    const m = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    this.ray.setFromCamera(m, this.camera);
    const hits = this.ray.intersectObject(this.root, true);
    const h = hits.find((x) => x.object.userData?.kind && x.object.userData.kind !== 'ceiling');
    if (!h) { this.app.select(null); return; }
    const { kind, id } = h.object.userData;
    this.app.select(kind, id);
  }

  updateSelection() {
    const sel = this.app.sel;
    const o = sel && this.index.get(sel.id);
    if (o) { this.selBox.box.setFromObject(o); this.selBox.box.expandByScalar(2); this.selBox.visible = true; }
    else this.selBox.visible = false;
    if (sel?.kind === 'item' && o && !this.app.viewOnly && !this.walking) {
      this.tcItem = this.app.scene.items.find((x) => x.id === sel.id);
      if (this.tc.object !== o) this.tc.attach(o);
    } else { this.tc.detach(); this.tcItem = null; }
  }

  setTcMode(mode) { this.tc.setMode(mode); this.tc.showY = mode === 'rotate'; this.tc.showX = this.tc.showZ = mode !== 'rotate'; }

  screenshot() {
    this.tc.detach(); this.selBox.visible = false;
    this.renderer.render(this.scene, this.camera);
    const url = this.renderer.domElement.toDataURL('image/png');
    this.updateSelection();
    return url;
  }

  // תמונה ממוזערת קטנה לשמירה (JPEG)
  thumbnail(w = 480, h = 300) {
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const shot = this.screenshot();
    return new Promise((res) => {
      const img = new Image();
      img.onload = () => {
        const g = cv.getContext('2d');
        const sr = img.width / img.height, dr = w / h;
        let sw = img.width, sh = img.height, sx = 0, sy = 0;
        if (sr > dr) { sw = img.height * dr; sx = (img.width - sw) / 2; } else { sh = img.width / dr; sy = (img.height - sh) / 2; }
        g.drawImage(img, sx, sy, sw, sh, 0, 0, w, h);
        res(cv.toDataURL('image/jpeg', 0.82));
      };
      img.src = shot;
    });
  }

  async exportGLB() {
    const { GLTFExporter } = await import('three/addons/exporters/GLTFExporter.js');
    const ex = new GLTFExporter();
    const clone = this.root.clone(true);
    clone.scale.setScalar(0.01); // ס"מ → מטרים
    return new Promise((res, rej) => ex.parse(clone, (r) => res(new Blob([r], { type: 'model/gltf-binary' })), rej, { binary: true }));
  }
}
