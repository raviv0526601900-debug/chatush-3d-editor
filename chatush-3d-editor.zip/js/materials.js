// חומרים: טקסטורות פרוצדורליות (נוצרות בדפדפן, בלי קבצים חיצוניים)
import * as THREE from 'three';

export const MATERIALS = {
  // קירות
  paint_white:   { name: 'צבע לבן', group: 'קיר', color: '#f4f1ec', rough: 0.92 },
  paint_warm:    { name: 'צבע שמנת חם', group: 'קיר', color: '#e9dfd0', rough: 0.92 },
  paint_sage:    { name: 'ירוק מרווה', group: 'קיר', color: '#a9b8a0', rough: 0.9 },
  paint_terra:   { name: 'טרקוטה', group: 'קיר', color: '#c4835f', rough: 0.9 },
  paint_navy:    { name: 'כחול עמוק', group: 'קיר', color: '#2f3d55', rough: 0.9 },
  paint_graphite:{ name: 'גרפיט', group: 'קיר', color: '#4a4a4d', rough: 0.9 },
  concrete:      { name: 'בטון חשוף', group: 'קיר', tex: 'concrete', color: '#a9a6a0', rough: 0.95 },
  brick:         { name: 'לבנים', group: 'קיר', tex: 'brick', color: '#a65b3f', rough: 0.95, scale: 120 },
  wall_tile:     { name: 'חיפוי קרמיקה', group: 'קיר', tex: 'tiles', color: '#eef0ef', grout: '#c9cccb', tile: 30, rough: 0.35 },
  // רצפות
  parquet_oak:   { name: 'פרקט אלון', group: 'רצפה', tex: 'parquet', color: '#b98a5a', rough: 0.6, scale: 200 },
  parquet_walnut:{ name: 'פרקט אגוז', group: 'רצפה', tex: 'parquet', color: '#6f4a30', rough: 0.55, scale: 200 },
  tile_porcelain:{ name: 'פורצלן 60×60', group: 'רצפה', tex: 'tiles', color: '#d9d5cf', grout: '#bdb8b0', tile: 60, rough: 0.4 },
  tile_large:    { name: 'פורצלן 120×60', group: 'רצפה', tex: 'tiles', color: '#cfcac3', grout: '#b5b0a8', tile: 120, tileH: 60, rough: 0.35 },
  terrazzo:      { name: 'טרצו', group: 'רצפה', tex: 'terrazzo', color: '#e6e1da', rough: 0.45, scale: 120 },
  marble:        { name: 'שיש קררה', group: 'רצפה', tex: 'marble', color: '#f1f0ee', rough: 0.25, scale: 160 },
  micro_concrete:{ name: 'מיקרו בטון', group: 'רצפה', tex: 'concrete', color: '#b8b3ab', rough: 0.7 },
  bath_tile:     { name: 'אריח אמבטיה 30×30', group: 'רצפה', tex: 'tiles', color: '#c9d3d6', grout: '#a9b3b6', tile: 30, rough: 0.4 },
  // רהיטים וגמרים
  wood_oak:      { name: 'עץ אלון', group: 'גמר', tex: 'wood', color: '#c19a6b', rough: 0.55, scale: 100 },
  wood_walnut:   { name: 'עץ אגוז', group: 'גמר', tex: 'wood', color: '#704b31', rough: 0.5, scale: 100 },
  formica_white: { name: 'פורמייקה לבנה', group: 'גמר', color: '#f5f5f2', rough: 0.4 },
  formica_grey:  { name: 'פורמייקה אפורה', group: 'גמר', color: '#8d8f91', rough: 0.4 },
  lacquer_green: { name: 'צבע תנור ירוק', group: 'גמר', color: '#5d6e5a', rough: 0.35 },
  lacquer_navy:  { name: 'צבע תנור כחול', group: 'גמר', color: '#2e3a52', rough: 0.35 },
  fabric_linen:  { name: 'בד פשתן', group: 'גמר', tex: 'fabric', color: '#d8cfc2', rough: 0.98, scale: 40 },
  fabric_grey:   { name: 'בד אפור', group: 'גמר', tex: 'fabric', color: '#8b8a88', rough: 0.98, scale: 40 },
  fabric_rust:   { name: 'בד חלודה', group: 'גמר', tex: 'fabric', color: '#a65e3a', rough: 0.98, scale: 40 },
  leather_cognac:{ name: 'עור קוניאק', group: 'גמר', color: '#9a5a32', rough: 0.55 },
  metal_black:   { name: 'מתכת שחורה', group: 'גמר', color: '#222224', rough: 0.4, metal: 0.6 },
  metal_brass:   { name: 'פליז', group: 'גמר', color: '#b89558', rough: 0.3, metal: 0.9 },
  steel:         { name: 'נירוסטה', group: 'גמר', color: '#b8bcbf', rough: 0.25, metal: 0.9 },
  stone_counter: { name: 'משטח אבן', group: 'גמר', tex: 'marble', color: '#ecebe8', rough: 0.25, scale: 120 },
  quartz_dark:   { name: 'קוורץ כהה', group: 'גמר', tex: 'terrazzo', color: '#3b3a39', rough: 0.3, scale: 90 },
  ceramic_white: { name: 'קרמיקה לבנה', group: 'גמר', color: '#fbfbfa', rough: 0.15 },
  glass:         { name: 'זכוכית', group: 'גמר', color: '#cfe3ea', rough: 0.05, opacity: 0.35 },
  plant:         { name: 'צמחייה', group: 'גמר', color: '#4f7a45', rough: 0.8 },
  soil:          { name: 'אדמה', group: 'גמר', color: '#5a4636', rough: 1 },
  // סימון לקבלן / חשמלאי
  mark_demolish: { name: 'להריסה', group: 'סימון', color: '#e0523f', rough: 0.8, opacity: 0.55 },
  mark_new:      { name: 'בנייה חדשה', group: 'סימון', color: '#3f7fe0', rough: 0.8 },
  mark_elec:     { name: 'חשמל', group: 'סימון', color: '#f2b705', rough: 0.5, emissive: '#5a4300' },
};

const texCache = new Map();
const matCache = new Map();

function rng(seed) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}
function shade(hex, f) {
  const c = new THREE.Color(hex);
  c.offsetHSL(0, 0, f);
  return '#' + c.getHexString();
}

function makeCanvas(size = 512) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  return [c, c.getContext('2d')];
}

function drawTexture(kind, m) {
  const [cv, g] = makeCanvas(512);
  const S = 512;
  const r = rng(kind.length * 977 + (m.color || '').length * 31);
  g.fillStyle = m.color; g.fillRect(0, 0, S, S);
  if (kind === 'parquet') {
    const rows = 8, pl = S / 2;
    for (let y = 0; y < rows; y++) {
      const off = (y % 2) * pl * 0.5;
      for (let x = -1; x < 3; x++) {
        g.fillStyle = shade(m.color, (r() - 0.5) * 0.12);
        g.fillRect(x * pl + off, y * (S / rows), pl - 2, S / rows - 2);
        g.strokeStyle = shade(m.color, -0.08); g.globalAlpha = 0.35;
        for (let k = 0; k < 6; k++) {
          const yy = y * (S / rows) + r() * (S / rows);
          g.beginPath(); g.moveTo(x * pl + off, yy); g.bezierCurveTo(x * pl + off + pl * 0.3, yy + 2, x * pl + off + pl * 0.6, yy - 2, x * pl + off + pl, yy); g.stroke();
        }
        g.globalAlpha = 1;
      }
    }
  } else if (kind === 'tiles') {
    const n = 4;
    g.fillStyle = m.grout || shade(m.color, -0.12); g.fillRect(0, 0, S, S);
    const tw = S / n, th = S / n * ((m.tileH || m.tile || 60) / (m.tile || 60));
    for (let y = 0; y * th < S; y++) for (let x = 0; x < n; x++) {
      g.fillStyle = shade(m.color, (r() - 0.5) * 0.04);
      g.fillRect(x * tw + 2, y * th + 2, tw - 4, th - 4);
    }
  } else if (kind === 'brick') {
    g.fillStyle = '#cfc6ba'; g.fillRect(0, 0, S, S);
    const bh = S / 8, bw = S / 4;
    for (let y = 0; y < 8; y++) for (let x = -1; x < 5; x++) {
      g.fillStyle = shade(m.color, (r() - 0.5) * 0.16);
      g.fillRect(x * bw + (y % 2) * bw / 2 + 3, y * bh + 3, bw - 6, bh - 6);
    }
  } else if (kind === 'wood') {
    for (let i = 0; i < 70; i++) {
      g.strokeStyle = shade(m.color, (r() - 0.5) * 0.18); g.globalAlpha = 0.5; g.lineWidth = 1 + r() * 3;
      const y = r() * S; g.beginPath(); g.moveTo(0, y);
      g.bezierCurveTo(S * 0.3, y + (r() - 0.5) * 20, S * 0.7, y + (r() - 0.5) * 20, S, y); g.stroke();
    }
    g.globalAlpha = 1;
  } else if (kind === 'marble') {
    for (let i = 0; i < 14; i++) {
      g.strokeStyle = i % 3 ? 'rgba(120,120,125,0.18)' : 'rgba(90,90,100,0.32)'; g.lineWidth = 0.6 + r() * 2.2;
      let x = r() * S, y = 0; g.beginPath(); g.moveTo(x, y);
      while (y < S) { x += (r() - 0.5) * 60; y += 20 + r() * 40; g.lineTo(x, y); }
      g.stroke();
    }
  } else if (kind === 'terrazzo') {
    for (let i = 0; i < 900; i++) {
      const pal = ['#8f8a83', '#5c5a57', '#c7a98a', '#ffffff', '#3d3c3b', '#b0b6b4'];
      g.fillStyle = pal[(r() * pal.length) | 0]; g.globalAlpha = 0.7;
      g.beginPath(); g.ellipse(r() * S, r() * S, 1 + r() * 5, 1 + r() * 4, r() * 3, 0, 7); g.fill();
    }
    g.globalAlpha = 1;
  } else if (kind === 'concrete') {
    const img = g.getImageData(0, 0, S, S);
    for (let i = 0; i < img.data.length; i += 4) {
      const n = (r() - 0.5) * 22;
      img.data[i] += n; img.data[i + 1] += n; img.data[i + 2] += n;
    }
    g.putImageData(img, 0, 0);
    for (let i = 0; i < 40; i++) { g.fillStyle = 'rgba(0,0,0,0.05)'; g.beginPath(); g.arc(r() * S, r() * S, 2 + r() * 10, 0, 7); g.fill(); }
  } else if (kind === 'fabric') {
    g.globalAlpha = 0.18;
    for (let i = 0; i < S; i += 3) { g.fillStyle = i % 6 ? '#000' : '#fff'; g.fillRect(i, 0, 1, S); g.fillRect(0, i, S, 1); }
    g.globalAlpha = 1;
  }
  const t = new THREE.CanvasTexture(cv);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

// ס"מ לכל חזרה של הטקסטורה
export function texScale(key) {
  const m = MATERIALS[key] || MATERIALS.paint_white;
  if (m.tex === 'tiles') return (m.tile || 60) * 4;
  return m.scale || 150;
}

export function getMaterial(key, { side } = {}) {
  const k = (MATERIALS[key] ? key : 'paint_white') + (side ? ':' + side : '');
  if (matCache.has(k)) return matCache.get(k);
  const m = MATERIALS[key] || MATERIALS.paint_white;
  let map = null;
  if (m.tex) {
    const tk = m.tex + ':' + m.color + ':' + (m.tile || '') + ':' + (m.tileH || '');
    if (!texCache.has(tk)) texCache.set(tk, drawTexture(m.tex, m));
    map = texCache.get(tk);
  }
  const mat = new THREE.MeshStandardMaterial({
    color: map ? '#ffffff' : m.color,
    map,
    roughness: m.rough ?? 0.8,
    metalness: m.metal ?? 0,
    transparent: m.opacity != null,
    opacity: m.opacity ?? 1,
    emissive: m.emissive ? new THREE.Color(m.emissive) : new THREE.Color(0),
    side: side === 'double' ? THREE.DoubleSide : THREE.FrontSide,
  });
  mat.userData.key = key;
  matCache.set(k, mat);
  return mat;
}

export function swatch(key) {
  const m = MATERIALS[key];
  return m ? m.color : '#ccc';
}
