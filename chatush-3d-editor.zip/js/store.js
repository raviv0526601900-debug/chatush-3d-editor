// שמירה וטעינה: Supabase (אותם חשבונות ואותה סביבת עבודה של האפליקציה), עם גיבוי מקומי
import { SUPABASE_URL, SUPABASE_ANON } from './config.js';

const NICHE_RULES = [
  [/אדריכל|architect/i, 'architect'],
  [/חשמל|electric/i, 'electrician'],
  [/נגר|carpent|wood/i, 'carpenter'],
  [/קבלן|שיפוצ|contract|renov|build/i, 'contractor'],
  [/עיצוב|מעצב|design|interior/i, 'designer'],
];
export function nicheOf(cfg) {
  const s = `${cfg?.profession ?? ''} ${cfg?.profession_name ?? ''} ${cfg?.archetype ?? ''}`;
  for (const [re, k] of NICHE_RULES) if (re.test(s)) return k;
  return 'designer';
}

class Store {
  constructor() {
    this.sb = window.supabase?.createClient(SUPABASE_URL, SUPABASE_ANON, { auth: { persistSession: true, storageKey: 'chatush3d-auth' } });
    this.user = null; this.studio = null; this.offline = !this.sb;
  }

  async init() {
    if (!this.sb) return null;
    // מסירת התחברות מהאפליקציה (postMessage מהחלון שפתח את העורך)
    window.addEventListener('message', async (e) => {
      const d = e.data;
      if (!d || d.type !== 'chatush3d:session' || !d.refresh_token) return;
      if (!/flutterflow\.app$|leaderbox\.online$|theouterspace\.online$|localhost/.test(new URL(e.origin).hostname)) return;
      await this.sb.auth.setSession({ access_token: d.access_token, refresh_token: d.refresh_token });
      location.reload();
    });
    try { window.opener?.postMessage({ type: 'chatush3d:ready' }, '*'); } catch (_) {}
    const { data } = await this.sb.auth.getSession();
    if (!data.session) return null;
    return this.afterLogin();
  }

  async afterLogin() {
    const { data: u } = await this.sb.auth.getUser();
    this.user = u?.user || null;
    if (!this.user) return null;
    const { data: cfg } = await this.sb.rpc('get_my_studio_config');
    this.studio = cfg ? { id: cfg.studio_id, name: cfg.name, niche: nicheOf(cfg), profession: cfg.profession_name } : null;
    return this.user;
  }

  async loginDemo(niche) {
    const r = await this.sb.functions.invoke('demo-login', { body: { niche } });
    const rt = r.data?.refresh_token;
    if (!rt) throw new Error('הכניסה לדמו נכשלה');
    const { error } = await this.sb.auth.refreshSession({ refresh_token: rt });
    if (error) throw error;
    return this.afterLogin();
  }

  async login(email, password) {
    const { error } = await this.sb.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message.includes('Invalid') ? 'מייל או סיסמה שגויים' : error.message);
    return this.afterLogin();
  }

  async logout() { await this.sb?.auth.signOut(); this.user = null; this.studio = null; }

  async listProjects() {
    const { data, error } = await this.sb.from('projects').select('id,family,address,status,created_at').eq('studio_id', this.studio.id).order('created_at', { ascending: false }).limit(100);
    if (error) throw error;
    return data || [];
  }

  async listModels() {
    const { data, error } = await this.sb.from('models').select('id,name,niche,project_id,thumb,updated_at,version').eq('studio_id', this.studio.id).order('updated_at', { ascending: false });
    if (error) throw error;
    return data || [];
  }

  async loadModel(id) {
    const { data, error } = await this.sb.from('models').select('*').eq('id', id).maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('המודל לא נמצא או שאין לכם הרשאה אליו');
    return data;
  }

  async createModel({ project_id, name, niche, scene, thumb }) {
    const { data, error } = await this.sb.from('models').insert({ studio_id: this.studio.id, project_id: project_id || null, name, niche, scene, thumb }).select('id,version').single();
    if (error) throw error;
    return data;
  }

  async saveModel(id, { name, scene, thumb }) {
    const row = { name, scene };
    if (thumb) row.thumb = thumb;
    const { data, error } = await this.sb.from('models').update(row).eq('id', id).select('id,version,updated_at').single();
    if (error) throw error;
    return data;
  }

  // ----- קבצי DWG/DXF בתיקיות הפרויקטים (טבלת files + אחסון studio-files)
  async listCadFiles(projectId) {
    let q = this.sb.from('files').select('id,name,ext,size_label,storage_path,project_id,created_at').eq('studio_id', this.studio.id).in('ext', ['dwg', 'dxf', 'DWG', 'DXF']).order('created_at', { ascending: false }).limit(200);
    if (projectId) q = q.eq('project_id', projectId);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  }

  async getFileRow(id) {
    const { data, error } = await this.sb.from('files').select('id,name,ext,storage_path,project_id').eq('id', id).maybeSingle();
    if (error) throw error;
    return data;
  }

  async downloadCad(row) {
    const { data, error } = await this.sb.storage.from('studio-files').download(row.storage_path);
    if (error) throw new Error('לא הצלחתי להוריד את הקובץ מסביבת העבודה');
    return new File([data], row.name.match(/\.(dwg|dxf)$/i) ? row.name : `${row.name}.${row.ext}`);
  }

  // שמירת הקובץ המקורי בתיקיית "תוכניות עבודה" של הפרויקט (שם אחסון באנגלית בלבד)
  async uploadCad(file, projectId) {
    const ext = (file.name.split('.').pop() || 'dwg').toLowerCase();
    const path = `${this.studio.id}/${projectId || 'general'}/plans/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const { error } = await this.sb.storage.from('studio-files').upload(path, file, { contentType: ext === 'dxf' ? 'application/dxf' : 'application/acad', upsert: false });
    if (error) throw new Error('ההעלאה לסביבת העבודה נכשלה: ' + error.message);
    const kb = Math.round(file.size / 1024);
    const name = file.name.replace(/\.(dwg|dxf)$/i, '');
    const { data, error: e2 } = await this.sb.from('files').insert({ studio_id: this.studio.id, project_id: projectId || null, folder: 4, name, ext, size_label: kb > 1024 ? `${(kb / 1024).toFixed(1)}MB` : `${kb}KB`, storage_path: path, author: this.user?.email?.split('@')[0] || '' }).select('id').single();
    if (e2) { await this.sb.storage.from('studio-files').remove([path]).catch(() => {}); throw new Error('הקובץ הועלה אבל לא נרשם בתיקייה: ' + e2.message); }
    return { id: data.id, path };
  }

  async shareModel(id) {
    const { data, error } = await this.sb.rpc('model_share', { p_id: id });
    if (error) throw error;
    return typeof data === 'string' ? data : data?.model_share;
  }

  async loadShared(token) {
    const { data, error } = await this.sb.rpc('model_shared', { p_token: token });
    if (error) throw error;
    if (!data) throw new Error('הקישור לא תקף או שהשיתוף בוטל');
    return data;
  }
}

export const store = new Store();

// גיבוי מקומי (טיוטה) — לשחזור אחרי רענון או ניתוק
export const local = {
  save(key, scene) { try { localStorage.setItem('c3d:' + key, JSON.stringify({ at: Date.now(), scene })); } catch (_) {} },
  load(key) { try { return JSON.parse(localStorage.getItem('c3d:' + key) || 'null'); } catch (_) { return null; } },
  clear(key) { try { localStorage.removeItem('c3d:' + key); } catch (_) {} },
};
