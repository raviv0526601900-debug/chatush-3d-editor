// מאגר רכיבים: רהיטים, מטבח, אמבטיה, חשמל ונגרות — כל רכיב נבנה פרמטרית לפי רוחב/עומק/גובה (ס"מ)
import * as THREE from 'three';
import { getMaterial } from './materials.js';

// קטגוריות לתצוגה בסרגל
export const CATEGORIES = [
  { key: 'living', name: 'סלון', icon: '🛋' },
  { key: 'bedroom', name: 'חדר שינה', icon: '🛏' },
  { key: 'dining', name: 'פינת אוכל', icon: '🍽' },
  { key: 'kitchen', name: 'מטבח', icon: '🍳' },
  { key: 'bath', name: 'אמבטיה', icon: '🛁' },
  { key: 'carpentry', name: 'נגרות', icon: '🪚' },
  { key: 'electric', name: 'חשמל', icon: '⚡' },
  { key: 'build', name: 'בנייה', icon: '🧱' },
  { key: 'decor', name: 'עיצוב', icon: '🪴' },
];

// mat = חומר ראשי, mat2 = משני
export const CATALOG = {
  sofa:          { name: 'ספה תלת־מושבית', cat: 'living', w: 220, d: 95, h: 85, mat: 'fabric_linen', mat2: 'wood_oak' },
  sofa_l:        { name: 'ספה פינתית', cat: 'living', w: 280, d: 180, h: 85, mat: 'fabric_grey', mat2: 'metal_black' },
  armchair:      { name: 'כורסה', cat: 'living', w: 85, d: 85, h: 85, mat: 'fabric_rust', mat2: 'wood_oak' },
  coffee_table:  { name: 'שולחן סלון', cat: 'living', w: 120, d: 65, h: 40, mat: 'wood_oak', mat2: 'metal_black' },
  tv_unit:       { name: 'מזנון טלוויזיה', cat: 'living', w: 200, d: 45, h: 50, mat: 'wood_walnut', mat2: 'metal_black' },
  bookcase:      { name: 'ספרייה', cat: 'living', w: 120, d: 35, h: 200, mat: 'wood_oak' },
  rug:           { name: 'שטיח', cat: 'decor', w: 240, d: 170, h: 1, mat: 'fabric_linen' },
  bed_double:    { name: 'מיטה זוגית', cat: 'bedroom', w: 180, d: 210, h: 100, mat: 'fabric_grey', mat2: 'wood_oak' },
  bed_single:    { name: 'מיטת יחיד', cat: 'bedroom', w: 90, d: 200, h: 90, mat: 'fabric_linen', mat2: 'wood_oak' },
  nightstand:    { name: 'שידת לילה', cat: 'bedroom', w: 50, d: 40, h: 50, mat: 'wood_oak' },
  dresser:       { name: 'קומודה', cat: 'bedroom', w: 140, d: 50, h: 85, mat: 'formica_white', mat2: 'metal_brass' },
  desk:          { name: 'שולחן עבודה', cat: 'bedroom', w: 140, d: 70, h: 75, mat: 'wood_oak', mat2: 'metal_black' },
  office_chair:  { name: 'כיסא עבודה', cat: 'bedroom', w: 60, d: 60, h: 95, mat: 'fabric_grey', mat2: 'metal_black' },
  dining_table:  { name: 'שולחן אוכל', cat: 'dining', w: 200, d: 95, h: 75, mat: 'wood_oak', mat2: 'metal_black' },
  dining_chair:  { name: 'כיסא אוכל', cat: 'dining', w: 48, d: 52, h: 85, mat: 'wood_oak', mat2: 'fabric_linen' },
  kitchen_base:  { name: 'ארון מטבח תחתון', cat: 'kitchen', w: 240, d: 60, h: 90, mat: 'formica_white', mat2: 'stone_counter', doors: 4 },
  kitchen_wall:  { name: 'ארון מטבח עליון', cat: 'kitchen', w: 240, d: 35, h: 70, z: 150, mat: 'formica_white', doors: 4 },
  kitchen_tall:  { name: 'ארון גבוה', cat: 'kitchen', w: 60, d: 60, h: 230, mat: 'formica_white', doors: 1 },
  island:        { name: 'אי מטבח', cat: 'kitchen', w: 200, d: 100, h: 92, mat: 'lacquer_green', mat2: 'stone_counter', doors: 3 },
  fridge:        { name: 'מקרר', cat: 'kitchen', w: 90, d: 70, h: 185, mat: 'steel' },
  oven:          { name: 'תנור בילט־אין', cat: 'kitchen', w: 60, d: 60, h: 60, z: 85, mat: 'metal_black' },
  sink_kitchen:  { name: 'כיור מטבח', cat: 'kitchen', w: 80, d: 50, h: 2, z: 90, mat: 'steel' },
  cooktop:       { name: 'כיריים', cat: 'kitchen', w: 70, d: 50, h: 2, z: 90, mat: 'metal_black' },
  washer:        { name: 'מכונת כביסה', cat: 'bath', w: 60, d: 60, h: 85, mat: 'ceramic_white' },
  toilet:        { name: 'אסלה תלויה', cat: 'bath', w: 38, d: 55, h: 40, mat: 'ceramic_white' },
  vanity:        { name: 'ארון אמבטיה', cat: 'bath', w: 100, d: 50, h: 55, z: 30, mat: 'wood_oak', mat2: 'ceramic_white' },
  shower:        { name: 'מקלחון', cat: 'bath', w: 90, d: 90, h: 200, mat: 'glass', mat2: 'bath_tile' },
  bathtub:       { name: 'אמבטיה', cat: 'bath', w: 170, d: 75, h: 58, mat: 'ceramic_white' },
  mirror:        { name: 'מראה', cat: 'bath', w: 80, d: 3, h: 90, z: 100, mat: 'glass' },
  wardrobe:      { name: 'ארון קיר', cat: 'carpentry', w: 240, d: 60, h: 250, mat: 'formica_white', mat2: 'metal_black', doors: 4 },
  wardrobe_slide:{ name: 'ארון הזזה', cat: 'carpentry', w: 200, d: 65, h: 250, mat: 'wood_oak', doors: 2, sliding: true },
  shelf:         { name: 'מדף צף', cat: 'carpentry', w: 120, d: 25, h: 4, z: 140, mat: 'wood_oak' },
  cabinet_custom:{ name: 'ארון בהתאמה', cat: 'carpentry', w: 120, d: 45, h: 90, mat: 'wood_walnut', mat2: 'metal_brass', doors: 2 },
  closet_unit:   { name: 'יחידת חדר ארונות', cat: 'carpentry', w: 100, d: 55, h: 240, mat: 'wood_oak', open: true },
  outlet:        { name: 'שקע חשמל', cat: 'electric', w: 8, d: 2, h: 8, z: 30, mat: 'formica_white', elec: true },
  outlet_counter:{ name: 'שקע מעל משטח', cat: 'electric', w: 8, d: 2, h: 8, z: 110, mat: 'formica_white', elec: true },
  switch:        { name: 'מפסק', cat: 'electric', w: 8, d: 2, h: 8, z: 110, mat: 'formica_white', elec: true },
  light_ceiling: { name: 'נקודת מאור תקרה', cat: 'electric', w: 30, d: 30, h: 8, z: -1, mat: 'mark_elec', elec: true, light: true },
  spot:          { name: 'ספוט שקוע', cat: 'electric', w: 9, d: 9, h: 2, z: -1, mat: 'mark_elec', elec: true, light: true },
  pendant:       { name: 'מנורה תלויה', cat: 'electric', w: 40, d: 40, h: 60, z: -1, mat: 'metal_black', light: true },
  panel:         { name: 'לוח חשמל', cat: 'electric', w: 45, d: 12, h: 70, z: 140, mat: 'formica_grey', elec: true },
  ac_unit:       { name: 'מזגן עילי', cat: 'electric', w: 90, d: 25, h: 30, z: 220, mat: 'formica_white', elec: true },
  data_point:    { name: 'נקודת תקשורת', cat: 'electric', w: 8, d: 2, h: 8, z: 30, mat: 'formica_grey', elec: true },
  column:        { name: 'עמוד', cat: 'build', w: 30, d: 30, h: 270, mat: 'concrete' },
  stairs:        { name: 'מדרגות', cat: 'build', w: 100, d: 300, h: 290, mat: 'wood_oak', steps: 16 },
  beam:          { name: 'קורה', cat: 'build', w: 300, d: 25, h: 40, z: 230, mat: 'concrete' },
  gypsum_box:    { name: 'סגירת גבס', cat: 'build', w: 100, d: 40, h: 270, mat: 'paint_white' },
  plant:         { name: 'עציץ', cat: 'decor', w: 45, d: 45, h: 120, mat: 'plant', mat2: 'soil' },
  floor_lamp:    { name: 'מנורת עמידה', cat: 'decor', w: 40, d: 40, h: 165, mat: 'metal_brass', light: true },
  art:           { name: 'תמונה על קיר', cat: 'decor', w: 90, d: 3, h: 60, z: 140, mat: 'wood_walnut' },
  box:           { name: 'קובייה חופשית', cat: 'build', w: 60, d: 60, h: 60, mat: 'formica_white' },
};

const M = (k) => getMaterial(k);
function box(w, h, d, mat, x = 0, y = 0, z = 0, r = 0) {
  const g = new THREE.BoxGeometry(Math.max(w, 0.1), Math.max(h, 0.1), Math.max(d, 0.1));
  const m = new THREE.Mesh(g, mat);
  m.position.set(x, y + h / 2, z);
  if (r) m.rotation.y = r;
  m.castShadow = true; m.receiveShadow = true;
  return m;
}
function cyl(r1, r2, h, mat, x = 0, y = 0, z = 0, seg = 24) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, seg), mat);
  m.position.set(x, y + h / 2, z); m.castShadow = true; m.receiveShadow = true;
  return m;
}
function legs(g, w, d, h, mat, inset = 4, r = 1.6) {
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) g.add(cyl(r, r, h, mat, sx * (w / 2 - inset), 0, sz * (d / 2 - inset), 10));
}
function fronts(g, w, h, d, n, mat, handleMat, y0 = 0, sliding = false) {
  const gap = 0.4, dw = w / n;
  for (let i = 0; i < n; i++) {
    const x = -w / 2 + dw * (i + 0.5);
    g.add(box(dw - gap, h - gap, 1.8, mat, x, y0 + gap / 2, d / 2 + 0.9 + (sliding && i % 2 ? 2 : 0)));
    if (handleMat) g.add(box(1.2, Math.min(18, h * 0.3), 1.6, handleMat, x + (i % 2 ? -1 : 1) * (dw / 2 - 5), y0 + h * 0.55, d / 2 + 2.6));
  }
}

// בונה את הרכיב: מרכז בתחתית, w לאורך X, d לאורך Z, h לגובה
export function buildItem(it) {
  const def = CATALOG[it.type] || CATALOG.box;
  const w = it.w ?? def.w, d = it.d ?? def.d, h = it.h ?? def.h;
  const A = M(it.mat || def.mat), B = M(it.mat2 || def.mat2 || def.mat);
  const g = new THREE.Group();
  switch (it.type) {
    case 'sofa': case 'sofa_l': {
      const seatH = 44, armW = 16, backD = 22;
      const sd = it.type === 'sofa_l' ? Math.min(d, 95) : d;   // עומק החלק הראשי
      const z0 = -d / 2 + sd / 2;
      g.add(box(w, 14, sd, B, 0, 0, z0));
      g.add(box(w - armW * 2, seatH - 14, sd - backD, A, 0, 14, z0 + backD / 2));
      g.add(box(w, h - 14, backD, A, 0, 14, z0 - sd / 2 + backD / 2));
      g.add(box(armW, 62 - 14, sd, A, -w / 2 + armW / 2, 14, z0));
      g.add(box(armW, 62 - 14, sd, A, w / 2 - armW / 2, 14, z0));
      const n = Math.max(1, Math.round((w - armW * 2) / 70));
      const cw = (w - armW * 2) / n;
      for (let i = 0; i < n; i++) g.add(box(cw - 3, 12, sd - backD - 6, A, -w / 2 + armW + cw * (i + 0.5), seatH, z0 + backD / 2));
      if (it.type === 'sofa_l' && d > sd) {
        // שזלונג בצד שמאל של הספה
        const cl = d - sd, cx = -w / 2 + armW + 45;
        g.add(box(90, 14, cl, B, cx, 0, d / 2 - cl / 2));
        g.add(box(90, seatH - 14 + 12, cl, A, cx, 14, d / 2 - cl / 2));
        g.add(box(armW, 62 - 14, cl, A, -w / 2 + armW / 2, 14, d / 2 - cl / 2));
      }
      break;
    }
    case 'armchair': {
      g.add(box(w - 10, 40, d - 10, A, 0, 6, 4)); legs(g, w - 12, d - 12, 8, B, 4, 1.5);
      g.add(box(w, h - 6, 16, A, 0, 6, -d / 2 + 8));
      g.add(box(12, 60, d, A, -w / 2 + 6, 6, 0)); g.add(box(12, 60, d, A, w / 2 - 6, 6, 0));
      break;
    }
    case 'coffee_table': case 'dining_table': case 'desk': {
      g.add(box(w, 4, d, A, 0, h - 4, 0)); legs(g, w, d, h - 4, B, 6, 2.2);
      if (it.type === 'desk') g.add(box(40, h - 10, d - 6, A, w / 2 - 22, 0, 0));
      break;
    }
    case 'dining_chair': case 'office_chair': {
      g.add(box(w, 4, d - 6, B, 0, 45, 3)); legs(g, w - 4, d - 8, 45, A, 3, 1.4);
      g.add(box(w, h - 49, 3, A, 0, 49, -d / 2 + 4));
      break;
    }
    case 'tv_unit': case 'dresser': case 'nightstand': case 'cabinet_custom': {
      const lift = it.type === 'tv_unit' ? 12 : 8;
      g.add(box(w, h - lift, d, A, 0, lift, 0)); legs(g, w, d, lift, M('metal_black'), 5, 1.2);
      fronts(g, w, h - lift, d, def.doors || Math.max(1, Math.round(w / 60)), A, B, lift);
      break;
    }
    case 'bookcase': case 'closet_unit': {
      const t = 2;
      g.add(box(t, h, d, A, -w / 2 + t / 2)); g.add(box(t, h, d, A, w / 2 - t / 2));
      g.add(box(w, t, d, A, 0, h - t)); g.add(box(w - 2 * t, h, 1, A, 0, 0, -d / 2 + 0.5));
      const n = Math.round(h / 38);
      for (let i = 0; i < n; i++) g.add(box(w - 2 * t, t, d, A, 0, (h / n) * i));
      if (it.type === 'closet_unit') g.add(cyl(1.2, 1.2, w - 6, M('metal_brass'), 0, h - 30, 0).rotateZ(Math.PI / 2));
      break;
    }
    case 'bed_double': case 'bed_single': {
      g.add(box(w, 30, d, B, 0, 0, 0));
      g.add(box(w - 6, 22, d - 8, M('fabric_linen'), 0, 30, 3));
      g.add(box(w, h, 8, A, 0, 0, -d / 2 + 4));
      const pn = it.type === 'bed_double' ? 2 : 1;
      for (let i = 0; i < pn; i++) g.add(box(w / pn - 14, 12, 40, M('ceramic_white'), -w / 2 + (w / pn) * (i + 0.5), 52, -d / 2 + 32));
      g.add(box(w - 4, 4, d * 0.55, A, 0, 52, d * 0.2));
      break;
    }
    case 'kitchen_base': case 'island': {
      g.add(box(w, 10, d - 6, M('metal_black'), 0, 0, -3));
      g.add(box(w, h - 14, d, A, 0, 10, 0));
      fronts(g, w, h - 14, d, def.doors || Math.max(1, Math.round(w / 60)), A, M('metal_black'), 10);
      g.add(box(w + 2, 4, d + 2, B, 0, h - 4, 0));
      break;
    }
    case 'kitchen_wall': case 'kitchen_tall': case 'wardrobe': case 'wardrobe_slide': {
      g.add(box(w, h, d, A, 0, 0, 0));
      fronts(g, w, h, d, def.doors || Math.max(1, Math.round(w / 60)), A, def.sliding ? null : M(it.mat2 || def.mat2 || 'metal_black'), 0, def.sliding);
      break;
    }
    case 'washer': {
      g.add(box(w, h, d, A));
      const door = new THREE.Mesh(new THREE.CylinderGeometry(w * 0.3, w * 0.3, 2, 28), M('glass'));
      door.rotation.x = Math.PI / 2; door.position.set(0, h * 0.45, d / 2 + 1); g.add(door);
      break;
    }
    case 'fridge': {
      g.add(box(w, h, d, A)); g.add(box(1.5, 60, 2, M('metal_black'), -w / 2 + 6, 90, d / 2 + 1));
      g.add(box(w - 1, 0.6, 0.6, M('metal_black'), 0, 120, d / 2 + 0.3));
      break;
    }
    case 'oven': { g.add(box(w, h, d, A)); g.add(box(w - 8, h - 18, 0.6, M('glass'), 0, 6, d / 2 + 0.3)); break; }
    case 'sink_kitchen': { g.add(box(w, 1, d, A)); g.add(box(w - 10, 1.2, d - 10, M('metal_black'), 0, 0.2)); g.add(cyl(1.4, 1.4, 30, A, 0, 1, -d / 2 + 5, 10)); break; }
    case 'cooktop': {
      g.add(box(w, 1, d, A));
      for (const [x, z] of [[-16, -10], [16, -10], [-16, 10], [16, 10]]) g.add(cyl(8, 8, 0.6, M('formica_grey'), x, 1, z));
      break;
    }
    case 'toilet': { g.add(box(w, 34, d, A, 0, 6, 0)); g.add(box(w, 50, 8, M('formica_white'), 0, 0, -d / 2 + 4)); break; }
    case 'vanity': { g.add(box(w, h - 12, d, A)); fronts(g, w, h - 12, d, 2, A, null); g.add(box(w, 12, d, B, 0, h - 12)); break; }
    case 'shower': {
      g.add(box(w, 4, d, B)); g.add(box(1, h, d, A, w / 2 - 0.5, 4, 0)); g.add(box(w, h, 1, A, 0, 4, d / 2 - 0.5));
      g.add(cyl(10, 10, 1, M('steel'), 0, h - 10, 0));
      break;
    }
    case 'bathtub': { g.add(box(w, h, d, A)); g.add(box(w - 12, 2, d - 12, M('bath_tile'), 0, h - 1.5)); break; }
    case 'mirror': case 'art': {
      g.add(box(w, h, d, A));
      if (it.type === 'art') g.add(box(w - 10, h - 10, 0.6, M('paint_terra'), 0, 5, d / 2 + 0.3));
      break;
    }
    case 'shelf': g.add(box(w, h, d, A)); break;
    case 'rug': g.add(box(w, 1, d, A)); break;
    case 'outlet': case 'outlet_counter': case 'switch': case 'data_point': {
      g.add(box(w, h, d, A));
      g.add(box(w * 0.5, h * 0.5, 0.6, M('mark_elec'), 0, h * 0.25, d / 2 + 0.3));
      break;
    }
    case 'light_ceiling': case 'spot': {
      g.add(cyl(w / 2, w / 2, h, A, 0, -h, 0));
      break;
    }
    case 'pendant': {
      g.add(cyl(0.4, 0.4, h - 18, M('metal_black'), 0, -h + 18, 0, 6));
      g.add(cyl(4, w / 2, 18, A, 0, -h, 0));
      break;
    }
    case 'panel': case 'ac_unit': { g.add(box(w, h, d, A)); if (it.type === 'ac_unit') g.add(box(w - 6, 2, 1, M('formica_grey'), 0, 3, d / 2)); break; }
    case 'column': case 'gypsum_box': case 'box': g.add(box(w, h, d, A)); break;
    case 'beam': g.add(box(w, h, d, A)); break;
    case 'stairs': {
      const n = def.steps || 16, sh = h / n, sd = d / n;
      for (let i = 0; i < n; i++) g.add(box(w, sh * (i + 1), sd, A, 0, 0, -d / 2 + sd * (i + 0.5)));
      break;
    }
    case 'plant': {
      g.add(cyl(w * 0.32, w * 0.26, 35, B));
      const leaf = M('plant');
      for (let i = 0; i < 7; i++) {
        const s = new THREE.Mesh(new THREE.SphereGeometry(w * 0.28, 12, 10), leaf);
        const a = i * 0.9;
        s.position.set(Math.cos(a) * w * 0.15, 55 + (i % 3) * (h - 70) / 3, Math.sin(a) * w * 0.15);
        s.scale.y = 1.3; s.castShadow = true; g.add(s);
      }
      break;
    }
    case 'floor_lamp': {
      g.add(cyl(14, 14, 2, M('metal_black'))); g.add(cyl(1, 1, h - 30, A, 0, 2));
      g.add(cyl(10, 18, 28, M('fabric_linen'), 0, h - 30));
      break;
    }
    default: g.add(box(w, h, d, A));
  }
  return g;
}

// גובה התקנה ברירת מחדל (z) — מנורות תקרה נמדדות מהתקרה
export function defaultZ(type, wallH) {
  const def = CATALOG[type] || {};
  if (def.z === -1) return wallH;
  return def.z ?? 0;
}
