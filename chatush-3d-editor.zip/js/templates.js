// תבניות בסיס לכל מקצוע. כל תבנית היא קובץ סצנה רגיל שאפשר לערוך עד הסוף.
let _n = 0;
const uid = (p) => `${p}${(++_n).toString(36)}`;

export function emptyScene(title = 'מודל חדש', niche = 'designer') {
  return { v: 1, title, niche, units: 'cm', settings: { wallHeight: 270, wallThick: 12, marks: niche === 'contractor' }, walls: [], openings: [], rooms: [], items: [] };
}

function T(title, niche, extra = {}) {
  _n = 0;
  const s = emptyScene(title, niche);
  Object.assign(s.settings, extra);
  const api = {
    s,
    wall(a, b, o = {}) { const id = uid('w'); s.walls.push({ id, a, b, t: o.t ?? 10, mat: o.mat || 'paint_white', kind: o.kind || 'existing' }); return id; },
    ext(pts, o = {}) { const ids = []; for (let i = 0; i < pts.length; i++) ids.push(api.wall(pts[i], pts[(i + 1) % pts.length], { t: 20, ...o })); return ids; },
    room(name, poly, floor = 'parquet_oak') { const id = uid('r'); s.rooms.push({ id, name, poly, floor }); return id; },
    door(wall, at, w = 90, o = {}) { s.openings.push({ id: uid('o'), wall, type: o.type || 'door', at, w, h: o.h ?? 210, flip: !!o.flip }); },
    win(wall, at, w = 120, o = {}) { s.openings.push({ id: uid('o'), wall, type: 'window', at, w, h: o.h ?? 130, sill: o.sill ?? 90 }); },
    item(type, x, y, rot = 0, o = {}) { s.items.push({ id: uid('i'), type, x, y, rot, ...o }); },
  };
  return api;
}

// ---------------------------------------------------------------- מעצבת פנים: דירת 5 חדרים מרוהטת
function designer() {
  const t = T('דירת 5 חדרים — קונספט עיצוב', 'designer');
  const [top, right, bottom, left] = t.ext([[0, 0], [1200, 0], [1200, 950], [0, 950]], { mat: 'paint_white' });
  const w700a = t.wall([700, 0], [700, 300]);
  const w700b = t.wall([700, 550], [700, 950]);
  const w820 = t.wall([820, 0], [820, 950]);
  const w300 = t.wall([700, 300], [820, 300]);
  const w550 = t.wall([0, 550], [700, 550]);
  const w350 = t.wall([350, 550], [350, 950]);
  const w400 = t.wall([820, 400], [1200, 400]);
  t.wall([1000, 400], [1000, 600], { mat: 'wall_tile' });
  const w600 = t.wall([820, 600], [1200, 600], { mat: 'wall_tile' });
  const w780 = t.wall([820, 780], [1200, 780]);
  // דלתות
  t.door(bottom, 440, 100);              // כניסה
  t.door(w300, 60, 80);                  // מחסן
  t.door(w550, 280, 80, { flip: true }); // ילדים 1
  t.door(w700b, 80, 80);                 // ילדים 2
  t.door(w820, 350, 90, { flip: true }); // הורים
  t.door(w820, 690, 80, { flip: true }); // אמבטיה
  t.door(w820, 870, 80, { flip: true }); // כביסה
  t.door(w400, 90, 80, { type: 'opening' });
  t.door(w400, 280, 80);
  // חלונות
  t.win(top, 180, 140, { sill: 100 });
  t.win(top, 540, 240, { sill: 0, h: 220 });   // יציאה למרפסת
  t.win(top, 1010, 160);
  t.win(left, 750, 100, { sill: 110 });        // מעל משטח המטבח
  t.win(left, 200, 140);
  t.win(right, 500, 60, { sill: 150, h: 60 });
  t.win(right, 690, 60, { sill: 150, h: 60 });
  t.win(bottom, 675, 140);
  // חדרים
  t.room('סלון, מטבח ופינת אוכל', [[0, 0], [700, 0], [700, 550], [0, 550]], 'tile_large');
  t.room('מחסן', [[700, 0], [820, 0], [820, 300], [700, 300]], 'tile_porcelain');
  t.room('מסדרון', [[700, 300], [820, 300], [820, 950], [700, 950]], 'tile_large');
  t.room('חדר ילדים', [[0, 550], [350, 550], [350, 950], [0, 950]], 'parquet_oak');
  t.room('חדר עבודה', [[350, 550], [700, 550], [700, 950], [350, 950]], 'parquet_oak');
  t.room('חדר הורים', [[820, 0], [1200, 0], [1200, 400], [820, 400]], 'parquet_walnut');
  t.room('חדר ארונות', [[820, 400], [1000, 400], [1000, 600], [820, 600]], 'parquet_walnut');
  t.room('מקלחת הורים', [[1000, 400], [1200, 400], [1200, 600], [1000, 600]], 'bath_tile');
  t.room('אמבטיה', [[820, 600], [1200, 600], [1200, 780], [820, 780]], 'bath_tile');
  t.room('חדר כביסה', [[820, 780], [1200, 780], [1200, 950], [820, 950]], 'tile_porcelain');
  // מטבח לאורך הקיר השמאלי
  t.item('kitchen_base', 40, 200, 270, { w: 360, mat: 'lacquer_green' });
  t.item('kitchen_wall', 28, 130, 270, { w: 180, mat: 'lacquer_green' });
  t.item('sink_kitchen', 40, 200, 270);
  t.item('cooktop', 40, 320, 270);
  t.item('fridge', 45, 425, 270);
  t.item('island', 215, 210, 270, { w: 220, d: 100 });
  // פינת אוכל
  t.item('dining_table', 200, 440, 0, { w: 180, d: 90 });
  for (const x of [140, 200, 260]) { t.item('dining_chair', x, 385, 0); t.item('dining_chair', x, 495, 180); }
  t.item('pendant', 200, 440, 0);
  // סלון
  t.item('rug', 540, 150, 90, { w: 240, d: 170 });
  t.item('sofa', 430, 150, 270);
  t.item('coffee_table', 550, 150, 90, { w: 110, d: 60 });
  t.item('tv_unit', 672, 150, 90, { w: 180 });
  t.item('armchair', 560, 262, 180);
  t.item('plant', 405, 285);
  t.item('floor_lamp', 405, 30);
  // ילדים
  t.item('bed_single', 110, 790, 270);
  t.item('desk', 250, 595, 0, { w: 120 });
  t.item('office_chair', 250, 650, 180);
  t.item('wardrobe', 315, 840, 90, { w: 160, d: 60 });
  // חדר עבודה
  t.item('desk', 525, 595, 0, { w: 160 });
  t.item('office_chair', 525, 650, 180);
  t.item('bookcase', 680, 820, 90, { w: 140 });
  t.item('armchair', 420, 880, 0);
  // הורים
  t.item('bed_double', 1010, 115, 0);
  t.item('nightstand', 890, 32, 0);
  t.item('nightstand', 1130, 32, 0);
  t.item('dresser', 1010, 370, 180, { w: 120 });
  t.item('art', 1010, 12, 0, { w: 120, z: 140 });
  // ארונות, מקלחות, כביסה
  t.item('closet_unit', 910, 567, 180, { w: 160 });
  t.item('shower', 1150, 450, 0);
  t.item('toilet', 1170, 560, 90);
  t.item('vanity', 1060, 575, 180, { w: 80 });
  t.item('bathtub', 1152, 690, 90);
  t.item('toilet', 1000, 633, 0);
  t.item('vanity', 900, 750, 180, { w: 90 });
  t.item('mirror', 900, 774, 180);
  t.item('washer', 1150, 910, 180);
  t.item('washer', 1085, 910, 180);
  t.item('kitchen_tall', 990, 910, 180, { w: 80 });
  t.item('art', 702, 640, 270, { w: 80 });
  return t.s;
}

// ---------------------------------------------------------------- אדריכל: בית פרטי, קומת קרקע
function architect() {
  const t = T('בית פרטי — קומת קרקע', 'architect', { wallHeight: 300 });
  const [top, right, bottom, left] = t.ext([[0, 0], [1500, 0], [1500, 1000], [0, 1000]], { mat: 'paint_warm', t: 25 });
  const wx900 = t.wall([900, 0], [900, 1000]);
  const wy600 = t.wall([900, 600], [1500, 600]);
  const wx1200 = t.wall([1200, 600], [1200, 1000]);
  const wy350 = t.wall([0, 650], [500, 650]);
  const wx500 = t.wall([500, 650], [500, 1000]);
  t.door(bottom, 750, 120);                  // כניסה ראשית (בין x=750)
  t.door(wx900, 300, 140, { type: 'opening' });
  t.door(wx900, 800, 90);
  t.door(wy600, 150, 90, { flip: true });
  t.door(wx1200, 200, 80);
  t.door(wy350, 400, 90);
  t.win(top, 250, 360, { sill: 0, h: 260 });    // חזית זכוכית לגינה
  t.win(top, 650, 300, { sill: 0, h: 260 });
  t.win(top, 1200, 220);
  t.win(left, 180, 160);
  t.win(left, 650, 200, { sill: 0, h: 240 });
  t.win(right, 300, 180);
  t.win(right, 800, 80, { sill: 160, h: 60 });
  t.win(bottom, 1000, 160);
  t.win(bottom, 300, 140);
  t.room('סלון ומטבח (חלל פתוח)', [[0, 0], [900, 0], [900, 650], [0, 650]], 'micro_concrete');
  t.room('לובי כניסה', [[500, 650], [900, 650], [900, 1000], [500, 1000]], 'terrazzo');
  t.room('חדר עבודה', [[0, 650], [500, 650], [500, 1000], [0, 1000]], 'parquet_oak');
  t.room('סוויטת אורחים', [[900, 0], [1500, 0], [1500, 600], [900, 600]], 'parquet_oak');
  t.room('שירותי אורחים', [[1200, 600], [1500, 600], [1500, 1000], [1200, 1000]], 'marble');
  t.room('חדר כביסה ושירות', [[900, 600], [1200, 600], [1200, 1000], [900, 1000]], 'tile_porcelain');
  t.item('island', 450, 420, 0, { w: 300, d: 110, mat: 'quartz_dark', mat2: 'stone_counter' });
  t.item('kitchen_base', 450, 620, 180, { w: 420, mat: 'wood_walnut' });
  t.item('kitchen_tall', 210, 620, 180, { w: 60, mat: 'wood_walnut' });
  t.item('fridge', 790, 610, 180);
  t.item('dining_table', 450, 250, 0, { w: 240, d: 100 });
  for (const x of [360, 450, 540]) { t.item('dining_chair', x, 190, 0); t.item('dining_chair', x, 310, 180); }
  t.item('sofa_l', 150, 230, 270, { w: 300, d: 200 });
  t.item('coffee_table', 290, 230, 90);
  t.item('stairs', 820, 250, 0, { w: 110, d: 380, h: 300 });
  t.item('column', 650, 0 + 330, 0, { w: 35, d: 35, h: 300 });
  t.item('desk', 250, 950, 180, { w: 180 });
  t.item('office_chair', 250, 890, 0);
  t.item('bookcase', 30, 830, 270, { w: 200 });
  t.item('bed_double', 1200, 120, 0);
  t.item('nightstand', 1080, 35);
  t.item('nightstand', 1320, 35);
  t.item('wardrobe_slide', 1200, 565, 180, { w: 260 });
  t.item('toilet', 1460, 900, 90);
  t.item('vanity', 1350, 960, 180, { w: 100, mat2: 'marble' });
  t.item('washer', 960, 960, 180);
  t.item('kitchen_base', 1080, 965, 180, { w: 160 });
  t.item('plant', 560, 950);
  t.item('plant', 860, 950);
  return t.s;
}

// ---------------------------------------------------------------- מעטפת דירת 4 חדרים (לחשמלאי ולקבלן)
function apartmentShell(t, mat = 'paint_white') {
  const [top, right, bottom, left] = t.ext([[0, 0], [1000, 0], [1000, 800], [0, 800]], { mat });
  const ids = {
    top, right, bottom, left,
    a: t.wall([600, 0], [600, 450]),          // סלון | הורים
    b: t.wall([0, 450], [1000, 450]),         // אזור יום | אזור לילה
    c: t.wall([350, 450], [350, 800]),        // ילדים | אמבטיה
    d: t.wall([550, 450], [550, 800]),        // אמבטיה | ילדים 2
  };
  return ids;
}

// ---------------------------------------------------------------- חשמלאי: תוכנית נקודות חשמל
function electrician() {
  const t = T('תוכנית חשמל — דירת 4 חדרים', 'electrician');
  const w = apartmentShell(t);
  t.door(w.bottom, 100, 100);   // כניסה מהצד הימני של הקיר התחתון? (הכיוון מ-1000 ל-0)
  t.door(w.a, 380, 90, { flip: true });
  t.door(w.b, 200, 80, { flip: true });
  t.door(w.b, 450, 80, { flip: true });
  t.door(w.b, 700, 80, { flip: true });
  t.win(w.top, 300, 240, { sill: 0, h: 220 });
  t.win(w.top, 800, 160);
  t.win(w.left, 200, 140);
  t.win(w.bottom, 800, 140);
  t.win(w.bottom, 450, 60, { sill: 150, h: 60 });
  t.room('סלון ומטבח', [[0, 0], [600, 0], [600, 450], [0, 450]], 'tile_porcelain');
  t.room('חדר הורים', [[600, 0], [1000, 0], [1000, 450], [600, 450]], 'parquet_oak');
  t.room('חדר ילדים', [[0, 450], [350, 450], [350, 800], [0, 800]], 'parquet_oak');
  t.room('אמבטיה', [[350, 450], [550, 450], [550, 800], [350, 800]], 'bath_tile');
  t.room('חדר ילדים 2', [[550, 450], [1000, 450], [1000, 800], [550, 800]], 'parquet_oak');
  // רהוט בסיסי להתמצאות
  t.item('kitchen_base', 40, 200, 270, { w: 300 });
  t.item('fridge', 45, 395, 270);
  t.item('sofa', 330, 380, 180);
  t.item('tv_unit', 330, 33, 0, { w: 180 });
  t.item('bed_double', 800, 115, 0);
  t.item('bed_single', 110, 650, 270);
  t.item('bed_single', 890, 650, 90);
  t.item('bathtub', 450, 760, 0);
  // נקודות חשמל
  t.item('panel', 960, 790, 180);
  t.item('data_point', 940, 794, 180);
  for (const [x, y, r] of [[20, 120, 90], [20, 300, 90], [330, 12, 0], [250, 12, 0], [410, 12, 0], [590, 300, 270], [200, 438, 180]]) t.item('outlet', x, y, r);
  for (const [x, y] of [[40, 120], [40, 260], [40, 330]]) t.item('outlet_counter', x - 28, y, 90);
  t.item('data_point', 330, 12, 0, { x: 300 });
  t.item('switch', 590, 420, 270);
  t.item('switch', 870, 790, 180);
  for (const [x, y] of [[150, 150], [150, 300], [300, 120], [450, 120], [300, 300], [450, 300]]) t.item('spot', x, y);
  t.item('pendant', 200, 220);
  // הורים
  t.item('light_ceiling', 800, 230);
  t.item('outlet', 680, 12, 0); t.item('outlet', 920, 12, 0); t.item('outlet', 988, 300, 270);
  t.item('switch', 620, 420, 90); t.item('switch', 690, 12, 0, { z: 90 }); t.item('switch', 910, 12, 0, { z: 90 });
  t.item('ac_unit', 800, 438, 180);
  // ילדים
  t.item('light_ceiling', 175, 625); t.item('outlet', 12, 560, 270); t.item('outlet', 338, 700, 90); t.item('switch', 230, 462, 0); t.item('ac_unit', 175, 788, 180);
  t.item('light_ceiling', 775, 625); t.item('outlet', 988, 560, 90); t.item('outlet', 562, 700, 270); t.item('switch', 730, 462, 0); t.item('ac_unit', 775, 788, 180);
  // אמבטיה
  t.item('light_ceiling', 450, 600); t.item('switch', 470, 438, 180); t.item('outlet', 538, 520, 90, { z: 130 });
  t.item('ac_unit', 300, 438, 180);
  return t.s;
}

// ---------------------------------------------------------------- נגר: מטבח וחדר שינה בהתאמה אישית
function carpenter() {
  const t = T('נגרות בהתאמה — מטבח וארון קיר', 'carpenter', { wallHeight: 260 });
  const [top, right, bottom, left] = t.ext([[0, 0], [900, 0], [900, 450], [0, 450]], { mat: 'paint_warm' });
  const mid = t.wall([480, 0], [480, 450]);
  t.door(mid, 330, 90);
  t.door(bottom, 650, 90);
  t.win(top, 240, 120, { sill: 110 });
  t.win(top, 700, 160);
  t.room('מטבח', [[0, 0], [480, 0], [480, 450], [0, 450]], 'parquet_oak');
  t.room('חדר שינה', [[480, 0], [900, 0], [900, 450], [480, 450]], 'parquet_oak');
  // מטבח בצורת L + אי
  t.item('kitchen_base', 220, 40, 0, { w: 420, mat: 'wood_oak', doors: 7 });
  t.item('kitchen_wall', 110, 28, 0, { w: 180, mat: 'wood_oak' });
  t.item('kitchen_wall', 380, 28, 0, { w: 150, mat: 'wood_oak' });
  t.item('kitchen_base', 40, 260, 270, { w: 240, mat: 'wood_oak' });
  t.item('kitchen_tall', 40, 410, 270, { w: 60, mat: 'wood_oak' });
  t.item('fridge', 445, 45, 0, { w: 70 });
  t.item('sink_kitchen', 240, 40, 0);
  t.item('cooktop', 40, 240, 270);
  t.item('oven', 40, 240, 270, { z: 10 });
  t.item('island', 250, 270, 0, { w: 180, d: 90, mat: 'lacquer_navy', mat2: 'stone_counter' });
  t.item('shelf', 240, 14, 0, { w: 90, z: 160 });
  // חדר שינה
  t.item('wardrobe_slide', 690, 415, 180, { w: 280 });
  t.item('bed_double', 690, 115, 0, { w: 160 });
  t.item('nightstand', 570, 32);
  t.item('nightstand', 810, 32);
  t.item('cabinet_custom', 868, 250, 90, { w: 140 });
  t.item('shelf', 520, 200, 270, { w: 100, z: 150 });
  return t.s;
}

// ---------------------------------------------------------------- קבלן שיפוצים: מצב קיים / הריסה / בנייה חדשה
function contractor() {
  const t = T('תוכנית שיפוץ — הריסה ובנייה', 'contractor', { marks: true });
  const w = apartmentShell(t, 'paint_white');
  // הקיר בין הסלון לחדר ההורים נהרס, ובמקומו קיר חדש מוזז
  t.s.walls.find((x) => x.id === w.a).kind = 'demolish';
  const nw = t.wall([700, 0], [700, 450], { kind: 'new' });
  const wb = t.s.walls.find((x) => x.id === w.c); wb.kind = 'demolish';
  const nb = t.wall([300, 450], [300, 800], { kind: 'new', mat: 'wall_tile' });
  t.door(w.bottom, 100, 100);
  t.door(nw, 380, 90, { flip: true });
  t.door(w.b, 150, 80, { flip: true });
  t.door(w.b, 420, 80, { flip: true });
  t.door(w.b, 700, 80, { flip: true });
  t.win(w.top, 300, 240, { sill: 0, h: 220 });
  t.win(w.top, 850, 140);
  t.win(w.left, 200, 140);
  t.win(w.bottom, 800, 140);
  t.room('סלון ומטבח מורחב', [[0, 0], [700, 0], [700, 450], [0, 450]], 'tile_large');
  t.room('חדר הורים', [[700, 0], [1000, 0], [1000, 450], [700, 450]], 'parquet_oak');
  t.room('חדר ילדים', [[0, 450], [300, 450], [300, 800], [0, 800]], 'parquet_oak');
  t.room('אמבטיה מורחבת', [[300, 450], [550, 450], [550, 800], [300, 800]], 'bath_tile');
  t.room('חדר ילדים 2', [[550, 450], [1000, 450], [1000, 800], [550, 800]], 'parquet_oak');
  t.item('kitchen_base', 40, 220, 270, { w: 340 });
  t.item('island', 260, 260, 270, { w: 200, d: 95 });
  t.item('fridge', 45, 410, 270);
  t.item('shower', 500, 750, 0);
  t.item('toilet', 330, 770, 270);
  t.item('vanity', 420, 778, 180, { w: 100 });
  t.item('gypsum_box', 525, 470, 0, { w: 50, d: 30 });
  t.item('beam', 350, 225, 90, { w: 450 });
  return t.s;
}

export const TEMPLATES = [
  { key: 'designer', name: 'מעצבת פנים', desc: 'דירת 5 חדרים מרוהטת עם חומרים וגימורים', build: designer },
  { key: 'architect', name: 'אדריכל', desc: 'בית פרטי, קומת קרקע עם חזית זכוכית', build: architect },
  { key: 'electrician', name: 'חשמלאי', desc: 'תוכנית נקודות חשמל, מאור ותקשורת', build: electrician },
  { key: 'carpenter', name: 'נגר', desc: 'מטבח L עם אי וארון הזזה בהתאמה', build: carpenter },
  { key: 'contractor', name: 'קבלן שיפוצים', desc: 'מצב קיים, הריסה ובנייה חדשה', build: contractor },
];

export function templateFor(key) {
  const t = TEMPLATES.find((x) => x.key === key) || TEMPLATES[0];
  return t.build();
}
