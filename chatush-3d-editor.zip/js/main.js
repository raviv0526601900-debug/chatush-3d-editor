// צ'אטוש תלת־ממד — העורך. מחבר בין התוכנית, התלת־ממד, חלונית המאפיינים, השמירה והייבוא.
import { Plan2D, fmtLen } from './plan2d.js';
import { View3D } from './view3d.js';
import { CATALOG, CATEGORIES } from './catalog.js';
import { MATERIALS, swatch } from './materials.js';
import { TEMPLATES, templateFor, emptyScene } from './templates.js';
import { wallLength, polyArea } from './builder3d.js';
import { store, local } from './store.js';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const params = new URLSearchParams(location.search);
const NICHE_NAME = { designer: 'עיצוב פנים', architect: 'אדריכלות', electrician: 'חשמל', carpenter: 'נגרות', contractor: 'שיפוצים' };

// ------------------------------------------------------------------ מצב
const app = {
  scene: emptyScene(),
  sel: null, tool: 'select', itemType: 'sofa',
  viewOnly: params.get('mode') === 'view' || params.has('share'),
  modelId: params.get('model'), projectId: params.get('project'), shareToken: params.get('share'),
  dirty: false, undo: [], redo: [], _id: 0,
  newId(p) { return p + Date.now().toString(36).slice(-4) + (++this._id).toString(36); },
  select(kind, id) {
    this.sel = kind ? { kind, id } : null;
    plan.render(); view.updateSelection(); renderProps();
    if (kind) showSide('props');
  },
  // נקודת שמירה בהיסטוריה + בנייה מחדש
  commit(label) {
    this.undo.push(this._snap); if (this.undo.length > 80) this.undo.shift();
    this.redo = [];
    this._snap = JSON.stringify(this.scene);
    this.dirty = true; setSave('dirty');
    plan.render(); view.rebuild(this.scene); renderProps(); stats();
    local.save(draftKey(), this.scene);
    if (label) status(label);
  },
  live(it, o = {}) { if (!o.from3d) view.liveItem(this.scene, it); else plan.render(); renderPropsLive(it); },
  hint(t) { const h = $('#hint'); h.textContent = t; h.classList.toggle('on', !!t); },
  toast,
};
const draftKey = () => app.modelId || app.shareToken || 'local';

function loadScene(scene, { fit = true, keepHistory = false } = {}) {
  app.scene = normalize(scene);
  if (!keepHistory) { app.undo = []; app.redo = []; }
  app._snap = JSON.stringify(app.scene);
  app.sel = null;
  $('#title').value = app.scene.title || 'מודל';
  $('#chkMarks').checked = !!app.scene.settings.marks;
  view.rebuild(app.scene, !fit);
  plan.render();
  if (fit) { requestAnimationFrame(() => { plan.fit(); view.fit(app.scene); }); }
  renderProps(); stats(); renderLayers(); renderRoomsStrip();
}
function normalize(s) {
  s = s && typeof s === 'object' ? s : emptyScene();
  s.settings = { wallHeight: 270, wallThick: 12, marks: false, ...(s.settings || {}) };
  for (const k of ['walls', 'openings', 'rooms', 'items']) if (!Array.isArray(s[k])) s[k] = [];
  return s;
}

function undo() {
  if (!app.undo.length) return;
  app.redo.push(app._snap);
  app._snap = app.undo.pop();
  app.scene = JSON.parse(app._snap); app.sel = null;
  app.dirty = true; setSave('dirty');
  plan.render(); view.rebuild(app.scene); renderProps(); stats();
}
function redo() {
  if (!app.redo.length) return;
  app.undo.push(app._snap);
  app._snap = app.redo.pop();
  app.scene = JSON.parse(app._snap); app.sel = null;
  plan.render(); view.rebuild(app.scene); renderProps(); stats();
}

// ------------------------------------------------------------------ תצוגות
const plan = new Plan2D($('#plan'), app);
const view = new View3D($('#view3d'), app);
// טלפון וטאבלט: צפייה בלבד (סיבוב, הגדלה והזזה באצבעות). עריכה מלאה רק במחשב.
app.mobile = (matchMedia('(pointer: coarse)').matches && Math.min(innerWidth, innerHeight) < 820) || innerWidth < 760;
if (app.mobile) app.viewOnly = true;
if (app.viewOnly) { $('#app').classList.replace('mode-edit', 'mode-view'); $('#app').classList.replace('view-split', 'view-3d'); }
if (app.mobile) { $('#app').classList.add('is-mobile'); $('#btnEditOpen').textContent = 'עריכה זמינה במחשב'; $('#btnEditOpen').disabled = true; }

$$('.seg button').forEach((b) => b.onclick = () => {
  $$('.seg button').forEach((x) => x.classList.toggle('on', x === b));
  const a = $('#app'); a.classList.remove('view-plan', 'view-split', 'view-3d'); a.classList.add('view-' + b.dataset.view);
  requestAnimationFrame(() => { plan.render(); view.resize(); });
});
$$('.view-tools [data-cam]').forEach((b) => b.onclick = () => {
  $$('.view-tools [data-cam]').forEach((x) => x.classList.toggle('on', x === b));
  view.setCam(b.dataset.cam, app.scene);
});
$('#chkCeiling').onchange = (e) => { view.ceiling = e.target.checked; view.rebuild(app.scene); };
$('#chkMarks').onchange = (e) => { app.scene.settings.marks = e.target.checked; app.commit('סימוני שיפוץ'); };

// ------------------------------------------------------------------ כלים
function setTool(t) {
  app.tool = t; plan.finishWall(); plan.measure = null;
  $$('.rail [data-tool]').forEach((b) => b.classList.toggle('on', b.dataset.tool === t));
  const hints = { wall: 'לחצו כדי להתחיל קיר, ושוב לכל פינה. הקלידו מספר ו-Enter לאורך מדויק', room: 'גררו מלבן כדי ליצור חדר עם קירות', door: 'לחצו על קיר להוספת דלת', window: 'לחצו על קיר להוספת חלון', item: `לחצו בתוכנית להצבת: ${CATALOG[app.itemType]?.name}`, measure: 'לחצו בשתי נקודות למדידה' };
  app.hint(hints[t] || '');
  if (t === 'item') showSide('catalog');
  plan.render();
}
$$('.rail [data-tool]').forEach((b) => b.onclick = () => setTool(b.dataset.tool));
$('.rail [data-act=fit]').onclick = () => { plan.fit(); view.fit(app.scene); };
$('.rail [data-act=walk]').onclick = () => {
  const a = $('#app');
  if (a.classList.contains('view-plan')) $('.seg [data-view=split]').click();
  view.setWalk(!view.walking, app.scene);
};

// ------------------------------------------------------------------ חלונית צד
function showSide(k) {
  $$('.side-tabs button').forEach((b) => b.classList.toggle('on', b.dataset.side === k));
  $('#sideProps').classList.toggle('hidden', k !== 'props');
  $('#sideCatalog').classList.toggle('hidden', k !== 'catalog');
  $('#sideLayers').classList.toggle('hidden', k !== 'layers');
  if (k === 'layers') renderLayers();
}
$$('.side-tabs button').forEach((b) => b.onclick = () => showSide(b.dataset.side));

function renderCatalog() {
  const q = $('#catSearch').value.trim();
  const out = [];
  for (const c of CATEGORIES) {
    const items = Object.entries(CATALOG).filter(([, d]) => d.cat === c.key && (!q || d.name.includes(q)));
    if (!items.length) continue;
    out.push(`<div class="cat-h">${c.icon} ${c.name}</div><div class="cat-grid">`);
    for (const [k, d] of items) out.push(`<button class="cat-item ${app.tool === 'item' && app.itemType === k ? 'on' : ''}" data-type="${k}">${esc(d.name)}<small>${d.w}×${d.d}×${d.h}</small></button>`);
    out.push('</div>');
  }
  $('#catList').innerHTML = out.join('') || '<p class="muted">לא נמצאו רכיבים</p>';
  $$('#catList [data-type]').forEach((b) => b.onclick = () => { app.itemType = b.dataset.type; setTool('item'); renderCatalog(); });
}
$('#catSearch').oninput = renderCatalog;

const num = (v, d = 0) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };
function field(label, html) { return `<div class="field"><label>${label}</label>${html}</div>`; }
function inp(key, val, opts = {}) { return `<input data-k="${key}" type="${opts.type || 'number'}" value="${esc(val)}" ${opts.step ? `step="${opts.step}"` : ''}>`; }
function swatches(key, cur, group) {
  return `<div class="swatches" data-sw="${key}">${Object.entries(MATERIALS).filter(([, m]) => group.includes(m.group)).map(([k, m]) => `<span class="sw ${k === cur ? 'on' : ''}" data-mat="${k}" title="${esc(m.name)}" style="background:${m.color}"></span>`).join('')}</div>`;
}

function renderProps() {
  const el = $('#sideProps'); const sc = app.scene; const sel = app.sel;
  if (!sel) {
    const area = sc.rooms.reduce((a, r) => a + polyArea(r.poly), 0) / 10000;
    el.innerHTML = `<p class="p-title">${esc(sc.title || 'מודל')}</p><div class="p-sub">${NICHE_NAME[sc.niche] || ''} · גובה קירות ${sc.settings.wallHeight} ס"מ</div>
      <div class="stats"><div class="stat-card"><b>${area.toFixed(1)}</b><span>מ"ר חדרים</span></div><div class="stat-card"><b>${sc.rooms.length}</b><span>חדרים</span></div>
      <div class="stat-card"><b>${sc.walls.length}</b><span>קירות</span></div><div class="stat-card"><b>${sc.items.length}</b><span>רכיבים</span></div></div>
      <div class="p-sec">הגדרות המודל</div>
      ${field('גובה קירות', inp('s.wallHeight', sc.settings.wallHeight))}
      ${field('עובי קיר חדש', inp('s.wallThick', sc.settings.wallThick))}
      <div class="p-sec">איך עובדים</div>
      <div class="empty-props">
        <p><b>קיר</b> <span class="kbd">W</span> לחיצה לכל פינה, Enter אחרי הקלדת אורך.</p>
        <p><b>חדר</b> <span class="kbd">R</span> גרירת מלבן — נוצרים קירות ורצפה.</p>
        <p><b>דלת / חלון</b> <span class="kbd">D</span> <span class="kbd">N</span> לחיצה על קיר.</p>
        <p><b>רכיב</b> <span class="kbd">F</span> לחיצה ליד קיר — הרכיב נצמד אליו.</p>
        <p><b>בחירה</b> לחיצה על כל דבר, בתוכנית או בתלת־ממד. <span class="kbd">Delete</span> למחיקה, <span class="kbd">Q</span> לסיבוב 90°.</p>
        <p><b>ייבוא DWG/DXF</b> — השרטוט מוצג כרקע וקירות מזוהים אוטומטית.</p>
      </div>`;
  } else if (sel.kind === 'wall') {
    const w = sc.walls.find((x) => x.id === sel.id); if (!w) return clearSel();
    el.innerHTML = `<p class="p-title">קיר</p><div class="p-sub">${fmtLen(wallLength(w))}</div>
      ${field('אורך (ס"מ)', inp('w.len', Math.round(wallLength(w))))}
      ${field('עובי', inp('w.t', w.t ?? sc.settings.wallThick))}
      ${field('גובה', inp('w.h', w.h ?? sc.settings.wallHeight))}
      ${field('סטטוס', `<select data-k="w.kind"><option value="existing">קיים</option><option value="new">בנייה חדשה</option><option value="demolish">להריסה</option></select>`)}
      <div class="p-sec">חיפוי וצבע</div>${swatches('w.mat', w.mat, ['קיר'])}
      <div class="p-actions"><button class="tb-btn" data-act="split">פיצול באמצע</button><button class="tb-btn" data-act="door">+ דלת</button><button class="tb-btn" data-act="win">+ חלון</button><button class="tb-btn danger" data-act="del">מחיקה</button></div>`;
    el.querySelector('[data-k="w.kind"]').value = w.kind || 'existing';
  } else if (sel.kind === 'opening') {
    const o = sc.openings.find((x) => x.id === sel.id); if (!o) return clearSel();
    el.innerHTML = `<p class="p-title">${o.type === 'window' ? 'חלון' : o.type === 'opening' ? 'פתח' : 'דלת'}</p><div class="p-sub">${o.w}×${o.h} ס"מ</div>
      ${field('סוג', `<select data-k="o.type"><option value="door">דלת ציר</option><option value="sliding">דלת הזזה</option><option value="window">חלון</option><option value="opening">פתח בלי דלת</option></select>`)}
      ${field('רוחב', inp('o.w', o.w))}${field('גובה', inp('o.h', o.h))}
      ${o.type === 'window' ? field('גובה אדן', inp('o.sill', o.sill ?? 90)) : ''}
      ${field('מיקום בקיר', inp('o.at', Math.round(o.at)))}
      ${o.type === 'door' ? field('כיוון פתיחה', `<select data-k="o.flip"><option value="0">פנימה</option><option value="1">החוצה</option></select>`) : ''}
      <div class="p-actions"><button class="tb-btn danger" data-act="del">מחיקה</button></div>`;
    el.querySelector('[data-k="o.type"]').value = o.type;
    const f = el.querySelector('[data-k="o.flip"]'); if (f) f.value = o.flip ? '1' : '0';
  } else if (sel.kind === 'room') {
    const r = sc.rooms.find((x) => x.id === sel.id); if (!r) return clearSel();
    el.innerHTML = `<p class="p-title">${esc(r.name)}</p><div class="p-sub">${(polyArea(r.poly) / 10000).toFixed(2)} מ"ר</div>
      ${field('שם החדר', inp('r.name', r.name, { type: 'text' }))}
      <div class="p-sec">ריצוף</div>${swatches('r.floor', r.floor, ['רצפה'])}
      <div class="p-sec">צבע כל קירות החדר</div>${swatches('r.walls', '', ['קיר'])}
      <div class="p-actions"><button class="tb-btn" data-act="fly">מבט על החדר</button><button class="tb-btn danger" data-act="del">מחיקת החדר</button></div>`;
  } else if (sel.kind === 'item') {
    const it = sc.items.find((x) => x.id === sel.id); if (!it) return clearSel();
    const d = CATALOG[it.type] || {};
    el.innerHTML = `<p class="p-title">${esc(it.label || d.name)}</p><div class="p-sub">${esc(CATEGORIES.find((c) => c.key === d.cat)?.name || '')}</div>
      ${field('כינוי', inp('i.label', it.label || '', { type: 'text' }))}
      <div class="p-sec">מידות (ס"מ)</div>
      <div class="grid3"><input data-k="i.w" type="number" value="${it.w ?? d.w}"><input data-k="i.d" type="number" value="${it.d ?? d.d}"><input data-k="i.h" type="number" value="${it.h ?? d.h}"><span>רוחב</span><span>עומק</span><span>גובה</span></div>
      <div class="p-sec">מיקום</div>
      <div class="grid3"><input data-k="i.x" type="number" value="${Math.round(it.x)}"><input data-k="i.y" type="number" value="${Math.round(it.y)}"><input data-k="i.z" type="number" value="${it.z ?? (d.z === -1 ? sc.settings.wallHeight : d.z ?? 0)}"><span>X</span><span>Y</span><span>גובה מהרצפה</span></div>
      ${field('סיבוב (°)', inp('i.rot', it.rot || 0))}
      <div class="p-sec">חומר ראשי</div>${swatches('i.mat', it.mat || d.mat, ['גמר', 'קיר'])}
      ${d.mat2 ? `<div class="p-sec">חומר משני</div>${swatches('i.mat2', it.mat2 || d.mat2, ['גמר'])}` : ''}
      <div class="p-actions"><button class="tb-btn" data-act="rot90">סיבוב 90°</button><button class="tb-btn" data-act="dup">שכפול</button><button class="tb-btn" data-act="tc">${view.tc.mode === 'rotate' ? 'הזזה בתלת־ממד' : 'סיבוב בתלת־ממד'}</button><button class="tb-btn danger" data-act="del">מחיקה</button></div>`;
  }
  bindProps(el);
}
function renderPropsLive(it) {
  const el = $('#sideProps');
  for (const k of ['x', 'y', 'rot']) { const i = el.querySelector(`[data-k="i.${k}"]`); if (i && document.activeElement !== i) i.value = Math.round(it[k] || 0); }
}
function clearSel() { app.sel = null; renderProps(); }

function bindProps(el) {
  const sc = app.scene, sel = app.sel;
  const target = () => sel && ({ wall: sc.walls, opening: sc.openings, room: sc.rooms, item: sc.items }[sel.kind] || []).find((x) => x.id === sel.id);
  el.querySelectorAll('[data-k]').forEach((input) => {
    input.onchange = () => {
      const [g, k] = input.dataset.k.split('.');
      const v = input.type === 'number' ? num(input.value) : input.value;
      if (g === 's') { sc.settings[k] = v; app.commit('הגדרות'); return; }
      const t = target(); if (!t) return;
      if (g === 'w' && k === 'len') {
        const L = wallLength(t), f = v / (L || 1);
        t.b = [Math.round(t.a[0] + (t.b[0] - t.a[0]) * f), Math.round(t.a[1] + (t.b[1] - t.a[1]) * f)];
      } else if (g === 'o' && k === 'flip') t.flip = v === '1';
      else if (g === 'i' && k === 'label') t.label = v || undefined;
      else t[k] = v;
      app.commit('עדכון ' + ({ w: 'קיר', o: 'פתח', r: 'חדר', i: 'רכיב' }[g]));
    };
  });
  el.querySelectorAll('[data-sw]').forEach((box) => box.querySelectorAll('[data-mat]').forEach((s) => s.onclick = () => {
    const [g, k] = box.dataset.sw.split('.'); const t = target(); if (!t) return;
    if (g === 'r' && k === 'walls') {
      // כל הקירות שנוגעים במצולע החדר
      const poly = t.poly;
      const near = (p) => poly.some((q, i) => { const r2 = poly[(i + 1) % poly.length]; const dx = r2[0] - q[0], dy = r2[1] - q[1], L2 = dx * dx + dy * dy || 1; const u = Math.max(0, Math.min(1, ((p[0] - q[0]) * dx + (p[1] - q[1]) * dy) / L2)); return Math.hypot(p[0] - q[0] - dx * u, p[1] - q[1] - dy * u) < 12; });
      for (const w of sc.walls) if (near(w.a) && near(w.b)) w.mat = s.dataset.mat;
    } else t[k] = s.dataset.mat;
    app.commit('החלפת חומר');
  }));
  el.querySelectorAll('[data-act]').forEach((b) => b.onclick = () => {
    const t = target(); const a = b.dataset.act;
    if (a === 'del') return deleteSel();
    if (a === 'split' && t) {
      const m = [Math.round((t.a[0] + t.b[0]) / 2), Math.round((t.a[1] + t.b[1]) / 2)];
      const nw = { ...t, id: app.newId('w'), a: m, b: [...t.b] }; t.b = m;
      const L = wallLength(t);
      for (const o of sc.openings) if (o.wall === t.id && o.at > L) { o.wall = nw.id; o.at -= L; }
      sc.walls.push(nw); app.commit('פיצול קיר'); return;
    }
    if ((a === 'door' || a === 'win') && t) {
      const L = wallLength(t), isW = a === 'win';
      sc.openings.push({ id: app.newId('o'), wall: t.id, type: isW ? 'window' : 'door', at: Math.round(L / 2), w: isW ? 120 : 90, h: isW ? 130 : 210, sill: isW ? 90 : 0 });
      app.commit(isW ? 'הוספת חלון' : 'הוספת דלת'); return;
    }
    if (a === 'fly' && t) { view.flyToRoom(t); return; }
    if (a === 'rot90' && t) { t.rot = ((t.rot || 0) + 90) % 360; app.commit('סיבוב'); return; }
    if (a === 'dup' && t) { const c = { ...t, id: app.newId('i'), x: t.x + 30, y: t.y + 30 }; sc.items.push(c); app.commit('שכפול'); app.select('item', c.id); return; }
    if (a === 'tc') { view.setTcMode(view.tc.mode === 'rotate' ? 'translate' : 'rotate'); renderProps(); }
  });
}

function deleteSel() {
  const sc = app.scene, sel = app.sel; if (!sel) return;
  if (sel.kind === 'wall') { sc.walls = sc.walls.filter((w) => w.id !== sel.id); sc.openings = sc.openings.filter((o) => o.wall !== sel.id); }
  if (sel.kind === 'opening') sc.openings = sc.openings.filter((o) => o.id !== sel.id);
  if (sel.kind === 'room') sc.rooms = sc.rooms.filter((r) => r.id !== sel.id);
  if (sel.kind === 'item') sc.items = sc.items.filter((i) => i.id !== sel.id);
  app.sel = null; app.commit('מחיקה');
}

function renderLayers() {
  const sc = app.scene;
  const has = sc.underlay?.segs?.length;
  $('#sideLayers').innerHTML = `
    <p class="p-title">שכבות ותצוגה</p><div class="p-sub">מה מוצג בתוכנית ובתלת־ממד</div>
    <label class="layer-row"><input type="checkbox" id="lyUnder" ${plan.underlayOn ? 'checked' : ''} ${has ? '' : 'disabled'}><span class="dot" style="background:#7a8fb0"></span>שרטוט מיובא (רקע) ${has ? `<small style="margin-inline-start:auto;color:#8a7b6c">${sc.underlay.segs.length.toLocaleString('he-IL')} קווים</small>` : '<small style="margin-inline-start:auto;color:#8a7b6c">אין</small>'}</label>
    <label class="layer-row"><input type="checkbox" id="lyMarks" ${sc.settings.marks ? 'checked' : ''}><span class="dot" style="background:#3f7fe0"></span>סימוני שיפוץ (חדש / הריסה)</label>
    ${has ? `<div class="p-actions"><button class="tb-btn danger" id="lyClear">הסרת השרטוט המיובא</button></div><p class="muted" style="margin-top:10px">שכבות מקור: ${esc((sc.underlay.layers || []).slice(0, 12).join(', '))}</p>` : ''}
    <div class="p-sec">מקרא</div>
    <div class="layer-row"><span class="dot" style="background:#3b322b"></span>קיר קיים</div>
    <div class="layer-row"><span class="dot" style="background:#3f7fe0"></span>בנייה חדשה</div>
    <div class="layer-row"><span class="dot" style="background:#e0523f"></span>להריסה</div>
    <div class="layer-row"><span class="dot" style="background:#f2b705"></span>חשמל ותאורה</div>`;
  const u = $('#lyUnder'); if (u) u.onchange = () => { plan.underlayOn = u.checked; plan.render(); };
  $('#lyMarks').onchange = (e) => { sc.settings.marks = e.target.checked; $('#chkMarks').checked = e.target.checked; app.commit('סימוני שיפוץ'); renderLayers(); };
  const c = $('#lyClear'); if (c) c.onclick = () => { delete sc.underlay; app.commit('הסרת שרטוט'); renderLayers(); };
}

function renderRoomsStrip() {
  const el = $('#roomsStrip');
  el.innerHTML = app.scene.rooms.map((r) => `<button data-r="${r.id}">${esc(r.name)}</button>`).join('') + `<button data-r="__all">כל המודל</button>` + (app.mobile ? '' : `<button data-r="__walk">סיור</button>`);
  el.querySelectorAll('button').forEach((b) => b.onclick = () => {
    if (b.dataset.r === '__all') return view.setCam('persp', app.scene);
    if (b.dataset.r === '__walk') return view.setWalk(!view.walking, app.scene);
    view.flyToRoom(app.scene.rooms.find((r) => r.id === b.dataset.r));
  });
}

function stats() {
  const sc = app.scene;
  const area = sc.rooms.reduce((a, r) => a + polyArea(r.poly), 0) / 10000;
  $('#stat').textContent = `${sc.rooms.length} חדרים · ${area.toFixed(1)} מ"ר · ${sc.walls.length} קירות · ${sc.openings.length} פתחים · ${sc.items.length} רכיבים` + (store.studio ? ` · ${store.studio.name}` : '');
}
let stT;
function status(t) { const s = $('#stat'); s.textContent = t; clearTimeout(stT); stT = setTimeout(stats, 1800); }
function toast(t, ms = 2600) { const el = $('#toast'); el.textContent = t; el.classList.add('on'); clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('on'), ms); }
function setSave(st, txt) {
  const el = $('#saveState');
  el.className = 'save-state ' + (st || '');
  el.textContent = txt || { dirty: 'שינויים לא שמורים', ok: 'נשמר', saving: 'שומר…' }[st] || '';
}

// ------------------------------------------------------------------ מקלדת
window.addEventListener('keydown', (e) => {
  if (e.target.closest('input, select, textarea') || view.walking || app.viewOnly) return;
  if (plan.typeKey(e.key)) { e.preventDefault(); return; }
  const k = e.key.toLowerCase(), mod = e.ctrlKey || e.metaKey;
  if (mod && k === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
  if (mod && k === 'y') { e.preventDefault(); redo(); return; }
  if (mod && k === 's') { e.preventDefault(); save(); return; }
  if (k === 'delete' || k === 'backspace') { deleteSel(); return; }
  if (k === 'escape') { setTool('select'); app.select(null); return; }
  if (k === 'q' && app.sel?.kind === 'item') { const it = app.scene.items.find((x) => x.id === app.sel.id); it.rot = ((it.rot || 0) + 90) % 360; app.commit('סיבוב'); return; }
  const map = { v: 'select', w: 'wall', r: 'room', d: 'door', n: 'window', f: 'item', m: 'measure' };
  if (map[k] && !mod) setTool(map[k]);
});
$('#btnUndo').onclick = undo; $('#btnRedo').onclick = redo;
$('#title').onchange = (e) => { app.scene.title = e.target.value; app.commit('שם המודל'); };

// ------------------------------------------------------------------ תבניות
function miniPlan(sc) {
  const b = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
  for (const w of sc.walls) for (const p of [w.a, w.b]) { b.minX = Math.min(b.minX, p[0]); b.minY = Math.min(b.minY, p[1]); b.maxX = Math.max(b.maxX, p[0]); b.maxY = Math.max(b.maxY, p[1]); }
  const W = b.maxX - b.minX + 60, H = b.maxY - b.minY + 60;
  const rooms = sc.rooms.map((r) => `<polygon points="${r.poly.map((p) => p.join(',')).join(' ')}" fill="${swatch(r.floor)}" opacity=".55"/>`).join('');
  const walls = sc.walls.map((w) => `<line x1="${w.a[0]}" y1="${w.a[1]}" x2="${w.b[0]}" y2="${w.b[1]}" stroke="${w.kind === 'demolish' ? '#e0523f' : w.kind === 'new' ? '#3f7fe0' : '#3b322b'}" stroke-width="${w.t || 12}" stroke-linecap="square"/>`).join('');
  const items = sc.items.map((it) => { const d = CATALOG[it.type] || {}; return `<rect x="${-(it.w ?? d.w) / 2}" y="${-(it.d ?? d.d) / 2}" width="${it.w ?? d.w}" height="${it.d ?? d.d}" transform="translate(${it.x} ${it.y}) rotate(${it.rot || 0})" fill="${d.elec ? '#f2b705' : '#c4a27c'}" opacity=".8"/>`; }).join('');
  return `<svg class="thumb" viewBox="${b.minX - 30} ${b.minY - 30} ${W} ${H}" preserveAspectRatio="xMidYMid meet" style="background:#fbf8f3">${rooms}${walls}${items}</svg>`;
}
function openTemplates() {
  const cur = store.studio?.niche;
  $('#tplGrid').innerHTML = [...TEMPLATES].sort((a, b) => (b.key === cur) - (a.key === cur)).map((t) => `<button class="tpl" value="${t.key}">${miniPlan(t.build())}<b>${t.name}${t.key === cur ? ' · המקצוע שלך' : ''}</b><span>${t.desc}</span></button>`).join('') +
    `<button class="tpl" value="__empty"><div class="thumb" style="display:grid;place-items:center;color:#8a7b6c;font-size:30px">＋</div><b>מודל ריק</b><span>מתחילים מאפס</span></button>`;
  $('#dlgTemplates').showModal();
}
$('#btnTemplates').onclick = openTemplates;
$('#dlgTemplates').addEventListener('close', () => {
  const v = $('#dlgTemplates').returnValue;
  if (!v || v === 'cancel') return;
  const keepUndo = app._snap;
  const sc = v === '__empty' ? emptyScene(app.scene.title || 'מודל חדש', store.studio?.niche || 'designer') : templateFor(v);
  if (app.modelId) sc.title = app.scene.title || sc.title;
  app.undo.push(keepUndo);
  loadScene(sc, { keepHistory: true });
  app._snap = JSON.stringify(app.scene);
  app.dirty = true; setSave('dirty');
  toast('התבנית נטענה — אפשר לערוך הכל');
});

// ------------------------------------------------------------------ ייבוא DWG/DXF
let importRes = null;
$('#btnImport').onclick = () => openImport();
function openImport() {
  importRes = null; $('#importInfo').innerHTML = ''; $('#btnDoImport').disabled = true; $('#wsFiles').innerHTML = '';
  $('#dlgImport').showModal();
  if (store.user && store.studio) listWsFiles();
}
// קבצי DWG/DXF שכבר נמצאים בתיקיות הפרויקטים של העסק
async function listWsFiles() {
  const el = $('#wsFiles');
  el.innerHTML = '<p class="muted"><span class="spinner"></span> מחפש קבצי DWG/DXF בסביבת העבודה…</p>';
  try {
    const rows = await store.listCadFiles(null);
    const mine = app.projectId ? [...rows.filter((r) => r.project_id === app.projectId), ...rows.filter((r) => r.project_id !== app.projectId)] : rows;
    el.innerHTML = rows.length ? `<div class="p-sec">או פתיחה מקובץ שכבר בסביבת העבודה (${rows.length})</div><div class="ws-list">${mine.map((r) => `<button type="button" class="ws-file" data-id="${r.id}"><span class="ext">${esc((r.ext || '').toUpperCase())}</span>${esc(r.name)}<small>${esc(r.size_label || '')}${r.project_id === app.projectId && app.projectId ? ' · הפרויקט הזה' : ''}</small></button>`).join('')}</div>`
      : '<p class="muted">אין עדיין קבצי DWG/DXF בתיקיות הפרויקטים. קובץ שתעלו כאן יישמר בתיקיית "תוכניות עבודה".</p>';
    el.querySelectorAll('.ws-file').forEach((b) => b.onclick = () => openWsFile(rows.find((r) => r.id === b.dataset.id)));
  } catch (e) { el.innerHTML = `<p class="muted">לא הצלחתי לטעון את קבצי סביבת העבודה (${esc(e.message || '')})</p>`; }
}
async function openWsFile(row) {
  if (!row) return;
  if (!$('#dlgImport').open) { $('#dlgImport').showModal(); $('#btnDoImport').disabled = true; }
  $('#importInfo').innerHTML = `<p><span class="spinner"></span> מוריד את ${esc(row.name)}…</p>`;
  try { const f = await store.downloadCad(row); await readFile(f, { fileId: row.id, projectId: row.project_id }); }
  catch (e) { $('#importInfo').innerHTML = `<p class="danger">${esc(e.message)}</p>`; }
}
const dz = $('#dropZone');
dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('over'); });
dz.addEventListener('dragleave', () => dz.classList.remove('over'));
dz.addEventListener('drop', (e) => { e.preventDefault(); dz.classList.remove('over'); if (e.dataTransfer.files[0]) readFile(e.dataTransfer.files[0]); });
$('#fileInput').onchange = (e) => e.target.files[0] && readFile(e.target.files[0]);
async function readFile(file, src = null) {
  const info = $('#importInfo');
  const say = (t) => { info.innerHTML = `<p><span class="spinner"></span> ${esc(t)}</p>`; };
  try {
    const { readCad, WALL_LAYER_RE } = await import('./importer.js');
    const res = await readCad(file, say);
    importRes = { res, file, src };
    const layers = [...res.layers.entries()].sort((a, b) => b[1] - a[1]);
    const unitName = { 0.1: 'מילימטרים', 1: 'סנטימטרים', 100: 'מטרים', 2.54: 'אינצ\'ים', 30.48: 'רגל' }[res.unit] || res.unit;
    info.innerHTML = `<p><b>${esc(file.name)}</b> · ${res.raw.length.toLocaleString('he-IL')} קווים · ${layers.length} שכבות ${res.version ? '· ' + esc(res.version) : ''}</p>
      ${field('יחידות השרטוט', `<select id="impUnit"><option value="0.1">מילימטרים</option><option value="1">סנטימטרים</option><option value="100">מטרים</option><option value="2.54">אינצ'ים</option></select>`)}
      ${res.guessed ? `<p class="muted">היחידות לא הוגדרו בקובץ — זוהו אוטומטית כ${unitName}. אפשר לשנות.</p>` : ''}
      <label class="row"><input type="checkbox" id="impUnder" checked> הצגת השרטוט כרקע בתוכנית</label>
      <label class="row"><input type="checkbox" id="impWalls" checked> יצירת קירות מהשכבות המסומנות</label>
      <label class="row"><input type="checkbox" id="impReplace" ${app.scene.walls.length ? '' : 'checked'}> החלפת המודל הנוכחי (במקום הוספה)</label>
      ${store.user && !src ? '<label class="row"><input type="checkbox" id="impKeep" checked> שמירת הקובץ המקורי בתיקיית "תוכניות עבודה" של הפרויקט</label>' : ''}
      ${src ? '<p class="muted">הקובץ נפתח מסביבת העבודה. המקור נשאר בתיקייה שלו.</p>' : ''}
      <div class="p-sec">שכבות לזיהוי קירות</div>
      ${layers.map(([n, c]) => `<label class="row"><input type="checkbox" class="impLayer" value="${esc(n)}" ${WALL_LAYER_RE.test(n) ? 'checked' : ''}> ${esc(n)} <small>${c.toLocaleString('he-IL')}</small></label>`).join('')}`;
    $('#impUnit').value = String(res.unit);
    if (!$$('.impLayer:checked').length && layers.length <= 3) $$('.impLayer').forEach((c) => (c.checked = true));
    $('#btnDoImport').disabled = false;
  } catch (err) {
    console.error(err);
    info.innerHTML = `<p class="danger">${esc(err.message || 'הייבוא נכשל')}</p>`;
  }
}
$('#btnDoImport').onclick = async (e) => {
  e.preventDefault();
  if (!importRes) return;
  const { toPlan, detectWalls } = await import('./importer.js');
  const unit = num($('#impUnit').value, 1);
  const segs = toPlan(importRes.res, unit);
  const chosen = new Set($$('.impLayer:checked').map((c) => c.value));
  const sc = $('#impReplace').checked ? emptyScene(importRes.file.name.replace(/\.(dwg|dxf)$/i, ''), app.scene.niche) : app.scene;
  if (!$('#impReplace').checked) app.undo.push(app._snap);
  if ($('#impUnder').checked) sc.underlay = { name: importRes.file.name, layers: [...importRes.res.layers.keys()], segs: segs.slice(0, 40000).map((s) => s.slice(1)) };
  let n = 0;
  if ($('#impWalls').checked && chosen.size) {
    const ws = detectWalls(segs.filter((s) => chosen.has(s[0])), { defaultT: sc.settings.wallThick || 12 });
    for (const w of ws) { sc.walls.push({ id: app.newId('w'), a: w.a, b: w.b, t: Math.max(5, Math.min(45, w.t)), mat: 'paint_white', kind: 'existing' }); n++; }
  }
  let fileId = importRes.src?.fileId || null;
  if (!fileId && store.user && $('#impKeep')?.checked) {
    try { fileId = (await store.uploadCad(importRes.file, app.projectId)).id; toast('הקובץ המקורי נשמר בתיקיית "תוכניות עבודה"'); }
    catch (err) { toast(err.message, 4000); }
  }
  sc.sources = [...(sc.sources || []), { name: importRes.file.name, file_id: fileId, at: new Date().toISOString() }];
  $('#dlgImport').close();
  if (sc !== app.scene) loadScene(sc); else { app.commit('ייבוא שרטוט'); plan.fit(); view.fit(app.scene); }
  app.dirty = true; setSave('dirty');
  toast(n ? `יובאו ${n} קירות מהשרטוט. אפשר לגרור, למחוק ולהשלים.` : 'השרטוט נוסף כרקע — ציירו מעליו קירות וחדרים');
  if (store.user) save(); // המודל נשמר מיד בסביבת העבודה
};

// ------------------------------------------------------------------ ייצוא ושיתוף
function download(name, blobOrUrl) {
  const a = document.createElement('a');
  a.href = typeof blobOrUrl === 'string' ? blobOrUrl : URL.createObjectURL(blobOrUrl);
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
}
const fileBase = () => (app.scene.title || 'model').replace(/[\\/:*?"<>|]/g, '').trim() || 'model';
$('#btnExport').onclick = () => $('#dlgExport').showModal();
$('#dlgExport').addEventListener('close', async () => {
  const v = $('#dlgExport').returnValue;
  if (v === 'png') download(fileBase() + '.png', view.screenshot());
  if (v === 'plan') download(fileBase() + ' - תוכנית.svg', new Blob([plan.exportSVG()], { type: 'image/svg+xml' }));
  if (v === 'glb') { toast('מכין קובץ GLB…'); download(fileBase() + '.glb', await view.exportGLB()); }
  if (v === 'json') download(fileBase() + '.json', new Blob([JSON.stringify(app.scene, null, 1)], { type: 'application/json' }));
});
$('#btnShare').onclick = async () => {
  if (!app.modelId || !store.user) { toast('שמרו את המודל בסביבת העבודה כדי לשתף קישור'); return; }
  try {
    if (app.dirty) await save();
    const tok = await store.shareModel(app.modelId);
    const url = `${location.origin}${location.pathname}?share=${encodeURIComponent(tok)}`;
    await navigator.clipboard.writeText(url).catch(() => {});
    toast('קישור הצפייה הועתק — אפשר לשלוח ללקוח', 3500);
    status(url);
  } catch (e) { toast('השיתוף נכשל: ' + (e.message || '')); }
};
$('#btnEditOpen').onclick = () => {
  const u = new URL(location.href); u.searchParams.delete('mode'); u.searchParams.delete('share');
  if (!app.modelId) { toast('העריכה זמינה לבעלי המודל מתוך האפליקציה'); return; }
  location.href = u.href;
};

// ------------------------------------------------------------------ שמירה
async function save() {
  if (app.viewOnly) return;
  app.scene.title = $('#title').value || app.scene.title;
  if (!store.user) { local.save('local', app.scene); app.dirty = false; setSave('ok', 'נשמר במחשב הזה'); toast('נשמר בדפדפן (בלי חשבון). התחברו כדי לשמור בסביבת העבודה.'); return; }
  setSave('saving');
  try {
    const thumb = await view.thumbnail();
    if (!app.modelId) {
      const r = await store.createModel({ project_id: app.projectId, name: app.scene.title, niche: app.scene.niche, scene: app.scene, thumb });
      app.modelId = r.id;
      const u = new URL(location.href); u.searchParams.set('model', r.id); history.replaceState(null, '', u.href);
    } else await store.saveModel(app.modelId, { name: app.scene.title, scene: app.scene, thumb });
    app.dirty = false; setSave('ok', 'נשמר בסביבת העבודה · ' + new Date().toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }));
    local.clear(draftKey());
    try { window.opener?.postMessage({ type: 'chatush3d:saved', id: app.modelId }, '*'); } catch (_) {}
  } catch (e) {
    console.error(e); setSave('dirty', 'השמירה נכשלה');
    toast('השמירה נכשלה: ' + (e.message || 'שגיאה'), 4000);
  }
}
$('#btnSave').onclick = save;
window.addEventListener('beforeunload', (e) => { if (app.dirty && !app.viewOnly) { e.preventDefault(); e.returnValue = ''; } });
setInterval(() => { if (app.dirty && store.user && app.modelId) save(); }, 60000); // שמירה אוטומטית כל דקה

// ------------------------------------------------------------------ כניסה ובחירת מודל
function loginDialog() {
  return new Promise((resolve) => {
    const d = document.createElement('dialog'); d.className = 'dlg';
    d.innerHTML = `<form method="dialog"><h2>כניסה לעורך התלת־ממד</h2><p class="muted">אותו חשבון של צ'אטוש. המודלים נשמרים בסביבת העבודה שלכם.</p>
      ${field('מייל', '<input id="lgEmail" type="email" autocomplete="email" style="direction:ltr">')}
      ${field('סיסמה', '<input id="lgPw" type="password" autocomplete="current-password" style="direction:ltr">')}
      <p id="lgErr" class="danger"></p>
      <div class="dlg-actions"><button class="tb-btn primary" value="login" id="lgGo">כניסה</button><button class="tb-btn txt" value="local">עבודה בלי חשבון</button></div>
      <div class="p-sec">או כניסה לחשבון הדגמה</div>
      <div class="tpl-grid" style="grid-template-columns:repeat(2,1fr)">${[['designer', 'מעצבת פנים'], ['architect', 'אדריכל'], ['contractor', 'קבלן שיפוצים'], ['carpenter', 'נגר']].map(([k, n]) => `<button class="tb-btn" value="demo:${k}">${n}</button>`).join('')}</div></form>`;
    document.body.appendChild(d);
    d.addEventListener('close', async () => {
      const v = d.returnValue;
      try {
        if (v === 'login') await store.login($('#lgEmail', d)?.value || d.querySelector('#lgEmail').value, d.querySelector('#lgPw').value);
        else if (v?.startsWith('demo:')) { toast('נכנס לחשבון ההדגמה…'); await store.loginDemo(v.slice(5)); }
        else { d.remove(); return resolve(null); }
        d.remove(); resolve(store.user);
      } catch (e) {
        d.querySelector('#lgErr').textContent = e.message || 'הכניסה נכשלה';
        d.showModal();
      }
    });
    d.showModal();
  });
}

function modelsDialog(models, projects) {
  return new Promise((resolve) => {
    const d = document.createElement('dialog'); d.className = 'dlg wide';
    const pname = (id) => { const p = projects.find((x) => x.id === id); return p ? p.family : 'בלי פרויקט'; };
    d.innerHTML = `<form method="dialog"><h2>המודלים של ${esc(store.studio?.name || 'הסטודיו')}</h2><p class="muted">בחרו מודל לעריכה או צרו חדש מתבנית ${esc(NICHE_NAME[store.studio?.niche] || '')}.</p>
      <div class="tpl-grid">
        <button class="tpl" value="__new"><div class="thumb" style="display:grid;place-items:center;color:#8a7b6c;font-size:34px">＋</div><b>מודל חדש</b><span>מתבנית המקצוע שלכם</span></button>
        ${models.map((m) => `<button class="tpl" value="${m.id}">${m.thumb ? `<img class="thumb" src="${m.thumb}" alt="">` : '<div class="thumb"></div>'}<b>${esc(m.name)}</b><span>${esc(pname(m.project_id))} · גרסה ${m.version}</span></button>`).join('')}
      </div>
      <div class="p-sec">פרויקט למודל חדש</div>
      <select id="mdProject" style="width:100%;padding:9px;border:1px solid #e4dacb;border-radius:10px">${projects.map((p) => `<option value="${p.id}">${esc(p.family)}${p.address ? ' · ' + esc(p.address) : ''}</option>`).join('')}<option value="">בלי פרויקט</option></select>
      <div class="dlg-actions"><button class="tb-btn txt" value="__logout">יציאה מהחשבון</button></div></form>`;
    document.body.appendChild(d);
    d.addEventListener('close', () => { const v = d.returnValue; const pid = d.querySelector('#mdProject').value; d.remove(); resolve({ v, pid }); });
    d.showModal();
  });
}

async function openFromWorkspace() {
  const [models, projects] = await Promise.all([store.listModels(), store.listProjects()]);
  if (app.projectId && !app.modelId) {
    const m = models.find((x) => x.project_id === app.projectId);
    if (m) app.modelId = m.id;
  }
  const fileParam = params.get('file');
  if (fileParam) {
    const row = await store.getFileRow(fileParam).catch(() => null);
    if (row) {
      app.projectId = row.project_id || app.projectId;
      const m = models.find((x) => x.project_id === app.projectId && app.projectId);
      if (m && !app.modelId) app.modelId = m.id;
      if (app.modelId) await openModel(app.modelId);
      else { const sc = emptyScene(row.name, store.studio?.niche || 'designer'); loadScene(sc); }
      await openWsFile(row);
      return;
    }
  }
  if (app.modelId) return openModel(app.modelId);
  const { v, pid } = await modelsDialog(models, projects);
  if (v === '__logout') { await store.logout(); location.href = location.pathname; return; }
  if (v && v !== '__new' && v !== 'cancel' && v !== '') return openModel(v);
  if (v !== '__new') {
    // החלון נסגר בלי בחירה — מציגים תבנית לעיון בלי ליצור מודל בסביבת העבודה
    loadScene(templateFor(store.studio?.niche || 'designer'));
    app.dirty = false; setSave('', 'לא נשמר — לחצו "שמירה" כדי ליצור מודל');
    return;
  }
  // חדש מתבנית המקצוע
  app.projectId = pid || null;
  const sc = templateFor(store.studio?.niche || 'designer');
  const p = projects.find((x) => x.id === pid);
  if (p) sc.title = `${sc.title} — ${p.family}`;
  loadScene(sc);
  await save();
  toast('נוצר מודל חדש מהתבנית ונשמר בסביבת העבודה');
}

async function openModel(id) {
  const m = await store.loadModel(id);
  app.modelId = m.id; app.projectId = m.project_id;
  const u = new URL(location.href); u.searchParams.set('model', m.id); history.replaceState(null, '', u.href);
  const draft = local.load(m.id);
  let scene = m.scene;
  if (draft && draft.at > new Date(m.updated_at).getTime() + 2000 && confirm('נמצאה טיוטה שלא נשמרה מהפעם הקודמת. לשחזר אותה?')) scene = draft.scene;
  loadScene(scene);
  setSave('ok', `גרסה ${m.version} · נשמר ${new Date(m.updated_at).toLocaleDateString('he-IL')}`);
}

// ------------------------------------------------------------------ אתחול
async function boot() {
  renderCatalog();
  setTool('select');
  try {
    if (app.shareToken) {
      const m = await store.loadShared(app.shareToken);
      loadScene(m.scene);
      $('#title').value = m.name; $('#title').readOnly = true;
      document.title = m.name + ' — צפייה בתלת־ממד';
      setSave('', m.studio_name ? 'שותף על ידי ' + m.studio_name : '');
      return;
    }
    if (params.get('template')) { loadScene(templateFor(params.get('template'))); return; }
    const u = window.C3D_PREVIEW ? null : await store.init();
    if (u && store.studio) { await openFromWorkspace(); stats(); return; }
    if (window.C3D_PREVIEW) { loadScene(templateFor('designer')); setSave('', 'תצוגה מקדימה — בלי שמירה'); setTimeout(openTemplates, 600); return; }
    if (params.get('local') !== '1' && store.sb) {
      const r = await loginDialog();
      if (r && store.studio) { await openFromWorkspace(); stats(); return; }
    }
    const draft = local.load('local');
    loadScene(draft?.scene || templateFor('designer'));
    setSave('', 'מצב מקומי — לא מחובר');
  } catch (e) {
    console.error(e);
    toast('שגיאה בטעינה: ' + (e.message || ''), 5000);
    loadScene(templateFor('designer'));
  }
}
boot();
window.__app = app; app._plan = plan; app._view = view; // לבדיקות
