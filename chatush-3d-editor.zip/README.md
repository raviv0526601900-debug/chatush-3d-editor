# צ'אטוש תלת־ממד — עורך מודלים בדפדפן

עורך תלת־ממד בעברית לתכנון דירות ובתים, חלק ממערכת **Chatush AI / STUDIO AI**.

- תוכנית דו־ממדית ותלת־ממד במקביל: קירות, חדרים, דלתות, חלונות, רהיטים, מטבח, אמבטיה, נגרות, חשמל ותאורה
- תבניות בסיס לכל מקצוע: מעצבת פנים, אדריכל, חשמלאי, נגר, קבלן שיפוצים (מצב קיים / הריסה / בנייה חדשה)
- ייבוא DWG (עם LibreDWG ב-WebAssembly) ו-DXF — הכל רץ בדפדפן, הקובץ לא נשלח לשרת
- ייצוא PNG, SVG, GLB ו-JSON
- שמירה בסביבת העבודה של העסק (Supabase), גרסאות, וקישור צפייה ללקוח
- בטלפון: צפייה בלבד, עם סיבוב והגדלה באצבעות

## רישיון
הקוד בתיקייה זו מופץ תחת **GPL-3.0** (ראו `LICENSE`), כי הוא משתמש ב-LibreDWG.

רכיבים:
- [LibreDWG](https://www.gnu.org/software/libredwg/) — GPL-3.0 © Free Software Foundation
- [@mlightcad/libredwg-web](https://github.com/mlightcad/libredwg-web) — GPL-3.0
- [three.js](https://threejs.org) — MIT
- [dxf-parser](https://github.com/gdsestimating/dxf-parser) — MIT
- [supabase-js](https://github.com/supabase/supabase-js) — MIT

## הרצה מקומית
```
python3 -m http.server 8080
# http://localhost:8080/?template=designer
```
פרמטרים: `?template=designer|architect|electrician|carpenter|contractor`, `?model=<id>`, `?project=<id>`, `?file=<id>`, `?share=<token>`, `?mode=view`, `?local=1`.
